import { Component, OnInit } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { AdminService } from '../../Services/admin.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-mutual-funds',
  templateUrl: './mutual-funds.component.html',
  styleUrls: ['./mutual-funds.component.css']
})
export class MutualFundsComponent implements OnInit {
  MutualFunds:any=[]
  message:any;
  constructor(private svc:AdminService,private router:Router) { }

  ngOnInit(): void {
     this.getMutualFundsDetails();
  }

  getMutualFundsDetails():void{
    this.svc.getMutualFundsDetails().subscribe( 
      (usrs)=>{
        this.MutualFunds=usrs;
        
      },
      (err:HttpErrorResponse)=>{
        this.message=err;
        console.log("Error Message :\n"+err);
      });
  }
  onClick(id:any){
    sessionStorage.setItem("mutualFundId",id)
    this.router.navigateByUrl('admin-mfupdate');
  }
}



