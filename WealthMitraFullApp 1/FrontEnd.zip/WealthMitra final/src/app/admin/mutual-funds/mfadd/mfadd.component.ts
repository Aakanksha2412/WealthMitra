import { Component, OnInit } from '@angular/core';
import { FormGroup, FormGroupDirective } from '@angular/forms';
import { AdminService } from '../../Services/admin.service';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-mfadd',
  templateUrl: './mfadd.component.html',
  styleUrls: ['./mfadd.component.css']
})
export class MfaddComponent implements OnInit {
  categories:any=[];
  sectors:any=[];
  mutualFundName:any;
  schemeCode:any;
  sectorName:any;
  categoryName:any;
  productName:any;
  products:any=[];  

  public MutualFundForm!:FormGroup;
  obj:any;
  constructor(private svc:AdminService, private http:HttpClient,private router:Router) { }

  ngOnInit(): void {
  
    this.svc.getCategoryDetails().subscribe(
      (data)=>{
        this.categories=data;
      }
    );
    this.svc.getSectorDetails().subscribe(
      (data)=>{
        this.sectors=data;
      }
    );
    this.svc.getProductDetails().subscribe(
      (data)=>{
        this.products=data;
      }
    ); 
  }  

  onSubmit(form:any):void{

    var id = sessionStorage.getItem("EmployeeId");
    console.log(id);

        this.obj={

          "MutualFundName":form.mutualFundName,
          "SchemeCode":form.schemeCode,
          "SectorName":form.sectorName,
          "ProductName":form.productName,
          "CategoryName":form.categoryName,
      };
    
        console.log(this.obj);
        this.http.post("http://localhost:4000/mutualfund/addmutualfund",this.obj).subscribe(
          (data)=>{
            console.log(data);
            alert("Uploaded MutualFund Details Successfully!!");
            this.router.navigateByUrl("admin-mutual-funds");
          },
          (err)=>{
            console.log(err);
          });
       
      }
    
}
