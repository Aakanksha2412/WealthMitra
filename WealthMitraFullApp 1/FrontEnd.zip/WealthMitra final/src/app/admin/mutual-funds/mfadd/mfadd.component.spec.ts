import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MfaddComponent } from './mfadd.component';

describe('MfaddComponent', () => {
  let component: MfaddComponent;
  let fixture: ComponentFixture<MfaddComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MfaddComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MfaddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
