import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { AdminService } from '../../Services/admin.service';

@Component({
  selector: 'app-mfupdate',
  templateUrl: './mfupdate.component.html',
  styleUrls: ['./mfupdate.component.css']
})
export class MfupdateComponent implements OnInit {

  categories:any=[];
  sectors:any=[];
  mutualFundName:any;
  schemeCode:any;
  sectorName:any;
  categoryName:any;
  productName:any;
  products:any=[];  

  public MutualFundForm!:FormGroup;
  obj:any;
  constructor(private svc:AdminService, private http:HttpClient,private router:Router) { }

  ngOnInit(): void {
  
    this.svc.getCategoryDetails().subscribe(
      (data)=>{
        this.categories=data;
      }
    );
    this.svc.getSectorDetails().subscribe(
      (data)=>{
        this.sectors=data;
      }
    );
    this.svc.getProductDetails().subscribe(
      (data)=>{
        this.products=data;
      }
    ); 
  }  

  onSubmit(form:any):void{

    var id = sessionStorage.getItem("mutualFundId");
    console.log(id);

        this.obj={

          "MutualFundName":form.mutualFundName,
          "SchemeCode":form.schemeCode,
          "SectorName":form.sectorName,
          "ProductName":form.productName,
          "CategoryName":form.categoryName,
      };
    
        console.log(this.obj);
        this.http.put("http://localhost:4000/mutualfund/updatemutualfund/"+id,this.obj).subscribe(
          (data)=>{
            console.log(data);
            alert("Uploaded MutualFund Details Successfully!!");
            this.router.navigateByUrl("admin-mutual-funds");
          },
          (err)=>{
            alert("Unsuccessful");
            console.log(err);
          });
       
      }

}
