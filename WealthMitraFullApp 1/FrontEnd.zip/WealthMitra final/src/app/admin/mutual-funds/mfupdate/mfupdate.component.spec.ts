import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MfupdateComponent } from './mfupdate.component';

describe('MfupdateComponent', () => {
  let component: MfupdateComponent;
  let fixture: ComponentFixture<MfupdateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MfupdateComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MfupdateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
