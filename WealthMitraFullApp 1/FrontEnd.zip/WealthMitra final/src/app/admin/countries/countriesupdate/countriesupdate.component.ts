import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { AdminService } from '../../Services/admin.service';

@Component({
  selector: 'app-countriesupdate',
  templateUrl: './countriesupdate.component.html',
  styleUrls: ['./countriesupdate.component.css']
})
export class CountriesupdateComponent implements OnInit {

  countryName:any;  
  public StateForm!:FormGroup;
  obj:any;
  constructor(private svc:AdminService, private http:HttpClient,private router:Router) { }

  ngOnInit(): void {
  
  }  

  onSubmit(form:any):void{

    var id = sessionStorage.getItem("CountryId");
    console.log(id);
      this.obj={
          "mainName":form.countryName
      };
    
      console.log(this.obj);
      this.http.put("http://localhost:4000/investor/updatecountry/"+id,this.obj).subscribe(
          (data)=>{
            console.log(data);
            alert("Uploaded Country Details Successfully!!");
            this.router.navigateByUrl("admin-countries");
          },
          (err)=>{
            alert("Unsuccessful");
            console.log(err);
          });
       
      }

}
