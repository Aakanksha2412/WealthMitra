import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CountriesupdateComponent } from './countriesupdate.component';

describe('CountriesupdateComponent', () => {
  let component: CountriesupdateComponent;
  let fixture: ComponentFixture<CountriesupdateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CountriesupdateComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CountriesupdateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
