import { Component, OnInit } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { AdminService } from '../../Services/admin.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-countries',
  templateUrl: './countries.component.html',
  styleUrls: ['./countries.component.css']
})
export class CountriesComponent implements OnInit {
  countries: any=[];
  message:any;
  constructor(private svc:AdminService,private router:Router) { }

  ngOnInit(): void {
     this.getCountryDetails();
  }

  getCountryDetails():void{
    this.svc.getCountryDetails().subscribe( 
      (usrs)=>{
        this.countries=usrs;
        
      },
      
      (err:HttpErrorResponse)=>{
        this.message=err;
        console.log("Error Message :\n"+err);
      });
    
  }
  onClick(id:any){
    sessionStorage.setItem("CountryId",id)
    this.router.navigateByUrl('admin-countriesupdate')
  }


}
