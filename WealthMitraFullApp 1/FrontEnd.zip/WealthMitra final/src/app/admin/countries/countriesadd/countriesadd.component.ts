import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { FormGroup } from '@angular/forms';
import { AdminService } from '../../Services/admin.service';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-countriesadd',
  templateUrl: './countriesadd.component.html',
  styleUrls: ['./countriesadd.component.css']
})
export class CountriesaddComponent implements OnInit {

  countryName:any;  
  public StateForm!:FormGroup;
  obj:any;
  constructor(private svc:AdminService, private http:HttpClient,private router:Router) { }

  ngOnInit(): void {
  
  }  

  onSubmit(form:any):void{

    var id = sessionStorage.getItem("EmployeeId");
    console.log(id);
      this.obj={
          "mainName":form.countryName
      };
    
      console.log(this.obj);
      this.http.post("http://localhost:4000/investor/Countryadd",this.obj).subscribe(
          (data)=>{
            console.log(data);
            alert("Uploaded Country Details Successfully!!");
            this.router.navigateByUrl("admin-countries");
          },
          (err)=>{
            console.log(err);
          });
       
      }
    

}
