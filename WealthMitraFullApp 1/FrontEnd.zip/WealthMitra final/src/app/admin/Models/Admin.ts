
////Use this For API////

export class Admin
{
    constructor(public ID:string,public name:string,public IsActive:string,public RecordCreatedBy:string,public RecordCreatedDate:string,public RecordModifiedreatedBy:string,public RecordModifiedDate:string)
    {

    }
}


