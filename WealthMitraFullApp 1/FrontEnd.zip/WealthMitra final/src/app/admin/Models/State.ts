
////Use this For API////

export class State
{
    constructor(public ID:string,public Name:string,public IsActive:string,public RecordCreatedBy:string,public RecordCreatedDate:string,public RecordModifiedBy:string,public RecordModifiedDate:string)
    {

    }
}


