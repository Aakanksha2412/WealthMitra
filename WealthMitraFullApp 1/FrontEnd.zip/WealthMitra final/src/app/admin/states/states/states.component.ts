import { Component, OnInit } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { AdminService } from '../../Services/admin.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-states',
  templateUrl: './states.component.html',
  styleUrls: ['./states.component.css']
})
export class StatesComponent implements OnInit {
  states: any=[];
  message:any;
  constructor(private svc:AdminService, private router:Router) { }

  ngOnInit(): void {
     this.getStateDetails();
  }

  getStateDetails():void{
    this.svc.getStateDetails().subscribe( 
      (usrs)=>{
        this.states=usrs;
        
      },
      
      (err:HttpErrorResponse)=>{
        this.message=err;
        console.log("Error Message :\n"+err);
      });
  
  }
  onClick(id:any){
    sessionStorage.setItem("StateId",id)
    this.router.navigateByUrl('admin-statesupdate')
  }
}


