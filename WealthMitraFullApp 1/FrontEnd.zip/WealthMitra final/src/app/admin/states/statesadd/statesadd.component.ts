import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { AdminService } from '../../Services/admin.service';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-statesadd',
  templateUrl: './statesadd.component.html',
  styleUrls: ['./statesadd.component.css']
})
export class StatesaddComponent implements OnInit {
  countryName:any;
  stateName:any;
countries:any=[];

  public StateForm!:FormGroup;
  obj:any;
  constructor(private svc:AdminService, private http:HttpClient,private router:Router) { }

  ngOnInit(): void {
  
       this.svc.getCountryDetails().subscribe(
      (data)=>{
        this.countries=data;
      }
    ); 
  }  

  onSubmit(form:any):void{

    var id = sessionStorage.getItem("EmployeeId");
    console.log(id);

        this.obj={

          "mainName":form.stateName,
          "subName":form.countryName
      };
    
        console.log(this.obj);
        this.http.post("http://localhost:4000/investor/Stateadd",this.obj).subscribe(
          (data)=>{
            console.log(data);
            alert("Uploaded States Details Successfully!!");
            this.router.navigateByUrl("admin-states");
          },
          (err)=>{
            console.log(err);
          });
       
      }
    



}
