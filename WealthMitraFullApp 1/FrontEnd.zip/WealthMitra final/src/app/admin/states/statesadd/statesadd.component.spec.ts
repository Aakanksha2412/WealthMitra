import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StatesaddComponent } from './statesadd.component';

describe('StatesaddComponent', () => {
  let component: StatesaddComponent;
  let fixture: ComponentFixture<StatesaddComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StatesaddComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StatesaddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
