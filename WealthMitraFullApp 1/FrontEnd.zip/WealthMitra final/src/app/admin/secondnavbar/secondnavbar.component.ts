import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-secondnavbar',
  templateUrl: './secondnavbar.component.html',
  styleUrls: ['./secondnavbar.component.css']
})
export class SecondnavbarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
