import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdminService } from '../../Services/admin.service';
import { AssetsService } from '../../Services/assets.service';
@Component({
  selector: 'app-assets',
  templateUrl: './assets.component.html',
  styleUrls: ['./assets.component.css']
})
export class AssetsComponent implements OnInit {
  assets : any=[];
  message:any;
  constructor(private svc:AdminService,private router:Router) { }

  ngOnInit(): void {
     this.getAssetDetails();
  }

  getAssetDetails():void{
    this.svc.getAssetDetails().subscribe( 
      (usrs)=>{
        this.assets=usrs;
        
      },
      
      (err:HttpErrorResponse)=>{
        this.message=err;
        console.log("Error Message :\n"+err);
      });
    
  
  }
  onClick(id:any):void{
    sessionStorage.setItem("AssetId",id)
    this.router.navigateByUrl('admin-assetupdate')
  }


  

}