import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import {Router} from '@angular/router';
@Component({
  selector: 'app-assetupdate',
  templateUrl: './assetupdate.component.html',
  styleUrls: ['./assetupdate.component.css']
})
export class AssetupdateComponent implements OnInit {
  assetId:any;
  AssetName:any;
  obj:any;
  public updateForm!:FormGroup;
  
  constructor( private router:Router, private http:HttpClient) { }

  ngOnInit(): void {
  }

  assetUpdate(form:any){
    this.assetId = sessionStorage.getItem("AssetId")
    this.obj = {
      "assetName":form.AssetName
    }
    this.http.put("http://localhost:4000/asset/updateasset/"+this.assetId,this.obj).subscribe(
      (data)=>{
        alert("successful");
        this.router.navigateByUrl('admin-assets')
      },
      (err:HttpErrorResponse)=>{
        console.log(err);
        alert("unsuccessful");
      }
    )
    

  }


}
