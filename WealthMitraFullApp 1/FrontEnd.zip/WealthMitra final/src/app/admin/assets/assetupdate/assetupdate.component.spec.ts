import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetupdateComponent } from './assetupdate.component';

describe('AssetupdateComponent', () => {
  let component: AssetupdateComponent;
  let fixture: ComponentFixture<AssetupdateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AssetupdateComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AssetupdateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
