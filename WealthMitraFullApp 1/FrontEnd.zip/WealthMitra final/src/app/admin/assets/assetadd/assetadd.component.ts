import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { FormGroup } from '@angular/forms';
import { AdminService } from '../../Services/admin.service';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-assetadd',
  templateUrl: './assetadd.component.html',
  styleUrls: ['./assetadd.component.css']
})
export class AssetaddComponent implements OnInit {
  assetName:any;
  public AssetForm!:FormGroup;
  obj:any;
  constructor(private svc:AdminService, private http:HttpClient,private router:Router) { }

  ngOnInit(): void {
  }  

  onSubmit(form:any):void{

        this.obj={
          "AssetName":form.assetName
      };
    
        console.log(this.obj);
        this.http.post("http://localhost:4000/asset/Assetadd",this.obj).subscribe(
          (data)=>{
            console.log(data);
            alert("Uploaded Asset Details Successfully!!");
            this.router.navigateByUrl("admin-assets");
          },
          (err)=>{
            console.log(err);
          });
       
      }
}
