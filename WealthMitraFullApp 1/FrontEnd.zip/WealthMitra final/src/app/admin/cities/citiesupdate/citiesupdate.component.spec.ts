import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CitiesupdateComponent } from './citiesupdate.component';

describe('CitiesupdateComponent', () => {
  let component: CitiesupdateComponent;
  let fixture: ComponentFixture<CitiesupdateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CitiesupdateComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CitiesupdateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
