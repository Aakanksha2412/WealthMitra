import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { AdminService } from '../../Services/admin.service';

@Component({
  selector: 'app-citiesupdate',
  templateUrl: './citiesupdate.component.html',
  styleUrls: ['./citiesupdate.component.css']
})
export class CitiesupdateComponent implements OnInit {
  cityName:any;
  stateName:any;
  CityId:any;
states:any=[];
  public CityForm!:FormGroup;
  obj:any;
  constructor(private svc:AdminService, private http:HttpClient,private router:Router) { }

  ngOnInit(): void {
 
    this.svc.getStateDetails().subscribe(
      (data)=>{
        this.states=data;
     
      }
    ); 

  }  

  onSubmit(form:any):void{

    this.CityId = sessionStorage.getItem("CityId");
    console.log(this.CityId );

        this.obj={

          "mainName":form.cityName,
          "subName":form.stateName
      };

      console.log(this.obj);
        this.http.put("http://localhost:4000/investor/updatecity/"+this.CityId ,this.obj).subscribe(
          (data)=>{
            console.log(data);
            alert("Uploaded Cities Details Successfully!!");
            this.router.navigateByUrl("admin-cities");
          },
          (err)=>{
            alert("Unsuccessful");
            console.log(err);
          });
       
      }

}
