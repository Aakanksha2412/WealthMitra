import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { AdminService } from '../../Services/admin.service';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
@Component({
  selector: 'app-citiesadd',
  templateUrl: './citiesadd.component.html',
  styleUrls: ['./citiesadd.component.css']
})
export class CitiesaddComponent implements OnInit {
  cityName:any;
  stateName:any;
states:any=[];
  public CityForm!:FormGroup;
  obj:any;
  constructor(private svc:AdminService, private http:HttpClient,private router:Router) { }

  ngOnInit(): void {
 
    this.svc.getStateDetails().subscribe(
      (data)=>{
        this.states=data;
     
      }
    ); 

  }  

  onSubmit(form:any):void{

    var id = sessionStorage.getItem("EmployeeId");
    console.log(id);

        this.obj={

          "mainName":form.cityName,
          "subName":form.stateName
      };
    
        console.log(this.obj);
        this.http.post("http://localhost:4000/investor/Cityadd",this.obj).subscribe(
          (data)=>{
            console.log(data);
            alert("Uploaded Cities Details Successfully!!");
            this.router.navigateByUrl("admin-cities");
          },
          (err)=>{
            console.log(err);
          });
       
      }
    
 

}
