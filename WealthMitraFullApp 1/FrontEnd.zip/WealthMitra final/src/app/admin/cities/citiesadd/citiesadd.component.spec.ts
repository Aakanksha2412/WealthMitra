import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CitiesaddComponent } from './citiesadd.component';

describe('CitiesaddComponent', () => {
  let component: CitiesaddComponent;
  let fixture: ComponentFixture<CitiesaddComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CitiesaddComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CitiesaddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
