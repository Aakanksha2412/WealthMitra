import { Component, OnInit } from '@angular/core';
import { AdminService } from '../../Services/admin.service';
import { HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-cities',
  templateUrl: './cities.component.html',
  styleUrls: ['./cities.component.css']
})
export class CitiesComponent implements OnInit {
  cities: any=[];
  message:any;
  constructor(private svc:AdminService,private router:Router) { }

  ngOnInit(): void {
     this.getCityDetails();
  }

  getCityDetails():void{
    this.svc.getCityDetails().subscribe( 
      (usrs)=>{
        this.cities=usrs;
        
      },
      
      (err:HttpErrorResponse)=>{
        this.message=err;
        console.log("Error Message :\n"+err);
      });
  }
  onClick(id:any){
    sessionStorage.setItem("CityId",id)
    this.router.navigateByUrl('admin-citiesupdate')
  }



}

