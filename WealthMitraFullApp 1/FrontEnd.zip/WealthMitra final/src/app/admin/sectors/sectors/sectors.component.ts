import { Component, OnInit } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { AdminService } from '../../Services/admin.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-sectors',
  templateUrl: './sectors.component.html',
  styleUrls: ['./sectors.component.css']
})
export class SectorsComponent implements OnInit {
  sectors: any=[];
 
  message:any;
  constructor(private svc:AdminService, private router:Router) { }

  ngOnInit(): void {
     this.getSectorDetails();
  }

  getSectorDetails():void{
    this.svc.getSectorDetails().subscribe( 
      (usrs)=>{
        this.sectors=usrs;
        
      },
      
      (err:HttpErrorResponse)=>{
        this.message=err;
        console.log("Error Message :\n"+err);
      });
  }
  onClick(id:any){
    sessionStorage.setItem("sectorID",id)
    this.router.navigateByUrl('admin-sectorsupdate')
  }

}

