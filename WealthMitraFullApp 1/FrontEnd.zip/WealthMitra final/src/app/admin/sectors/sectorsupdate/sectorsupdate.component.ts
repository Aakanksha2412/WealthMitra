import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { AdminService } from '../../Services/admin.service';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-sectorsupdate',
  templateUrl: './sectorsupdate.component.html',
  styleUrls: ['./sectorsupdate.component.css']
})
export class SectorsupdateComponent implements OnInit {

  sectorName:any;  
  public StateForm!:FormGroup;
  obj:any;
  constructor(private svc:AdminService, private http:HttpClient,private router:Router) { }

  ngOnInit(): void {
  
  }  

  onSubmit(form:any):void{
      this.obj={
          "SectorName":form.sectorName
      };
      var id=sessionStorage.getItem("sectorID");
      console.log(id);
      console.log(this.obj);
      this.http.put("http://localhost:4000/Sector/updatesector/"+id,this.obj).subscribe(
          (data)=>{
            console.log(data);
            alert("Update Sector Details Successfully!!");
            this.router.navigateByUrl("admin-sectors");
          },
          (err)=>{
            alert("Unsuccessfull?");

            console.log(err);
          });
       
      }
}
