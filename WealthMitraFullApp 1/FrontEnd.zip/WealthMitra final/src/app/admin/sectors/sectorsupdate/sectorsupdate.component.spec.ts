import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SectorsupdateComponent } from './sectorsupdate.component';

describe('SectorsupdateComponent', () => {
  let component: SectorsupdateComponent;
  let fixture: ComponentFixture<SectorsupdateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SectorsupdateComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SectorsupdateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
