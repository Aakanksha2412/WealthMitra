import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SectorsaddComponent } from './sectorsadd.component';

describe('SectorsaddComponent', () => {
  let component: SectorsaddComponent;
  let fixture: ComponentFixture<SectorsaddComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SectorsaddComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SectorsaddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
