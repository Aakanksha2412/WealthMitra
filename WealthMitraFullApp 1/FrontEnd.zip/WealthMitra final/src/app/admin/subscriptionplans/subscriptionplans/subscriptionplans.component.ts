import { Component, OnInit } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { AdminService } from '../../Services/admin.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-subscriptionplans',
  templateUrl: './subscriptionplans.component.html',
  styleUrls: ['./subscriptionplans.component.css']
})
export class SubscriptionplansComponent implements OnInit {
  plans : any=[] ;
  message:any;
  constructor(private svc:AdminService, private router:Router) { }

  ngOnInit(): void {
     this.getSubscriptionPlanDetails();
  }

  getSubscriptionPlanDetails():void{
    this.svc.getSubscriptionPlanDetails().subscribe( 
      (usrs)=>{
        this.plans=usrs;  
      },
      
      (err:HttpErrorResponse)=>{
        this.message=err;
        console.log("Error Message :\n"+err);
      });
    
  
  }

  onClick(id:any){
    sessionStorage.setItem("subscriptionPlanID",id)
    this.router.navigateByUrl('admin-subscriptionplansupdate')
  }

}
