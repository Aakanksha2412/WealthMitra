import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { AdminService } from '../../Services/admin.service';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-subscriptionadd',
  templateUrl: './subscriptionadd.component.html',
  styleUrls: ['./subscriptionadd.component.css']
})
export class SubscriptionaddComponent implements OnInit {
  planName:any;
  planPrice:any; 
  planFeactures:any;

  public PlanForm!:FormGroup;
  obj:any;
  constructor(private svc:AdminService, private http:HttpClient,private router:Router) { }

  ngOnInit(): void {
  
  }  

  onSubmit(form:any):void{

        this.obj={
          "SubscriptionPlanName":form.planName,
          "Price":form.planPrice,
          "Features":form.planFeactures

      };
    
        console.log(this.obj);
        this.http.post("http://localhost:4000/Subscription/addPlan",this.obj).subscribe(
          (data)=>{
            console.log(data);
            alert("Uploaded SubscriptionPlan Details Successfully!!");
            this.router.navigateByUrl("admin-subscriptionplans");
          },
          (err)=>{
            console.log(err);
          });
       
      }

}
