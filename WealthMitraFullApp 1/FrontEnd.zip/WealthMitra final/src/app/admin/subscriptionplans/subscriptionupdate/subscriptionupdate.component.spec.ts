import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SubscriptionupdateComponent } from './subscriptionupdate.component';

describe('SubscriptionupdateComponent', () => {
  let component: SubscriptionupdateComponent;
  let fixture: ComponentFixture<SubscriptionupdateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SubscriptionupdateComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SubscriptionupdateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
