import { Component, OnInit } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { AdminService } from '../../Services/admin.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-categories',
  templateUrl: './categories.component.html',
  styleUrls: ['./categories.component.css']
})
export class CategoriesComponent implements OnInit {
  categories:any=[];
  message:any;;
  constructor(private svc:AdminService, private router:Router) { }

    ngOnInit(): void {

      this.getCategoryDetails();
    
    }
    getCategoryDetails():void{
      this.svc.getCategoryDetails().subscribe( 
        (usrs)=>{
          this.categories=usrs;
            
        },
        
        (err:HttpErrorResponse)=>{
          this.message=err;
          console.log("Error Message :\n"+err);
        });
  }

  onClick(id:any):void{
    console.log(id);
    sessionStorage.setItem("CategoryId",id)
    this.router.navigateByUrl('admin-category-update')
  }
}
