import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { AdminService } from '../../Services/admin.service';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-category-update',
  templateUrl: './category-update.component.html',
  styleUrls: ['./category-update.component.css']
})
export class CategoryUpdateComponent implements OnInit {

    products:any=[];
    categoryName:any;
    productName:any; 

    public CategoryForm!:FormGroup;
    obj:any;
    categoryId: any;
    constructor(private svc:AdminService, private http:HttpClient,private router:Router) { }

    ngOnInit(): void {
    
      this.svc.getProductDetails().subscribe(
        (data)=>{
          this.products=data;
        }
      );
    }  

    onSubmit(form:any):void{
      this.categoryId = sessionStorage.getItem("CategoryId")
      console.log(this.categoryId);

        this.obj={
          "productName":form.productName,
          "categoryName":form.categoryName
      };

      console.log(this.obj);
    
       
        this.http.put("http://localhost:4000/category/updatecategory/"+this.categoryId,this.obj).subscribe(
          (data)=>{
            alert("Updated category Details Successfully!!");
            this.router.navigateByUrl("admin-categories");
          },
          (err)=>{
            alert("unsuccessful");
            console.log(err);
          });
       
      }

}
