import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { FormGroup } from '@angular/forms';
import { AdminService } from '../../Services/admin.service';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-category-add',
  templateUrl: './category-add.component.html',
  styleUrls: ['./category-add.component.css']
})
export class CategoryAddComponent implements OnInit {
    products:any=[];
    categoryName:any;
    productName:any; 

    public CategoryForm!:FormGroup;
    obj:any;
    constructor(private svc:AdminService, private http:HttpClient,private router:Router) { }

    ngOnInit(): void {
    
      this.svc.getProductDetails().subscribe(
        (data)=>{
          this.products=data;
        }
      );
    }  

    onSubmit(form:any):void{

        this.obj={
          "ProductName":form.productName,
          "CategoryName":form.categoryName
      };
    
       
        this.http.post("http://localhost:4000/category/insertcategory",this.obj).subscribe(
          (data)=>{
            console.log(data);
            alert("Uploaded category Details Successfully!!");
            this.router.navigateByUrl("admin-categories");
          },
          (err)=>{
            console.log(err);
          });
       
      }
 
}
