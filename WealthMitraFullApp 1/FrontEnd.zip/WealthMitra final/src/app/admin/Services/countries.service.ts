import { Injectable } from '@angular/core';
///***Use this For API*********
// import { HttpClient } from '@angular/common/http';
// import { Observable } from 'rxjs';
// import {Countries } from './Countries';
//**************** */
@Injectable({
  providedIn: 'root'
})

  export class CountriesService {
    country:any=[]
    constructor() {
    this.country=[
    {"Id":1,"Name":"India","IsActive":1,"RecordCreatedBy":"Admin","RecordCreatedDate":"","RecordModifiedBy":"Admin","RecordModifiedDate":""},
    {"Id":2,"Name":"USA","IsActive":1,"RecordCreatedBy":"Admin","RecordCreatedDate":"","RecordModifiedBy":"Admin","RecordModifiedDate":""},
    {"Id":3,"Name":"Africa","IsActive":1,"RecordCreatedBy":"Admin","RecordCreatedDate":"","RecordModifiedBy":"Admin","RecordModifiedDate":""},
  
    ];
    }
    GetAll():any{
    return this.country;
    }
  
    //*******Use this For API***********//
  
  // constructor(private http:HttpClient) { }
  
  
  // getDetails():Observable<Countries>
  // {
   
  //   let url="https://localhost:5001/api/customers/";
  
  //   return this.http.get<Countries>(url);
  
  // }
  
  
  // putDetails():Observable<Countries>
  // {
   
  //   let url="https://localhost:5001/api/customers/";
  
  //   return this.http.put<Countries>(url);
  
  // }
  
  
  // postDetails():Observable<Countries>
  // {
   
  //   let url="https://localhost:5001/api/customers/";
  
  //   return this.http.post<Countries>(url);
  
  // }
  
  
  
  // deleteDetails():Observable<Countries>
  // {
   
  //   let url="https://localhost:5001/api/customers/";
  
  //   return this.http.delete<Countries>(url);
  
  // }
     
   
  }
