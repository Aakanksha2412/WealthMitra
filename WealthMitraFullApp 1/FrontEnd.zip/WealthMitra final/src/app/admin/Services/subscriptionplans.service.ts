import { Injectable } from '@angular/core';
///***Use this For API*********
// import { HttpClient } from '@angular/common/http';
// import { Observable } from 'rxjs';
// import {Subscription } from './Subscription';
//**************** */
@Injectable({
  providedIn: 'root'
})
export class SubscriptionplansService {
  plan:any=[]
  constructor() { this.plan=[
    {"Id":1,"Name":"Platinum","Price":2000,"Features":" 20 Advices/month and portfolio Management","IsActive":1,"RecordCreatedBy":"Admin","RecordCreatedDate":"","RecordModifiedBy":"","RecordModifiedDate":""},
    {"Id":2,"Name":"Gold","Price":1500,"Features":" 12 Advices/month and portfolio Management","IsActive":1,"RecordCreatedBy":"Admin","RecordCreatedDate":"","RecordModifiedBy":"","RecordModifiedDate":""},
    {"Id":3,"Name":"Silver","Price":1000,"Features":"8 Advices/month and portfolio Management","IsActive":1,"RecordCreatedBy":"Admin","RecordCreatedDate":"","RecordModifiedBy":"","RecordModifiedDate":""},
    {"Id":4,"Name":"PMS","Price":500,"Features":"portfolio Management","IsActive":1,"RecordCreatedBy":"Admin","RecordCreatedDate":"","RecordModifiedBy":"","RecordModifiedDate":""},
    ];
}
GetAll():any{
return this.plan;
  }


  //*******Use this For API***********//

// constructor(private http:HttpClient) { }


// getDetails():Observable<Subscription>
// {
 
//   let url="https://localhost:5001/api/customers/";

//   return this.http.get<Subscription>(url);

// }



// putDetails():Observable<Subscription>
// {
 
//   let url="https://localhost:5001/api/customers/";

//   return this.http.put<Subscription>(url);

// }


// postDetails():Observable<Subscription>
// {
 
//   let url="https://localhost:5001/api/customers/";

//   return this.http.post<Subscription>(url);

// }



// deleteDetails():Observable<Subscription>
// {
 
//   let url="https://localhost:5001/api/customers/";

//   return this.http.delete<Subscription>(url);

// }
}
