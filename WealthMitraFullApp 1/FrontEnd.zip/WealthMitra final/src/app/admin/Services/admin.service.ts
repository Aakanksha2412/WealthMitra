import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class AdminService {

  constructor(private http:HttpClient) { }
  getAssetDetails() :Observable<Object> {
    let url:any="http://localhost:4000/asset/assets";
    return this.http.get<Object>(url);
    
    }
    getCategoryDetails() :Observable<Object> {
      let url:any="http://localhost:4000/category/categories";
      return this.http.get<Object>(url);
      
    }
    getRolesDetails() :Observable<Object> {
      let url:any="http://localhost:4000/investor/roles";
      return this.http.get<Object>(url);
      
    }
    getAdminProfileDetails(username:string) :Observable<any> {
      let url:any="http://localhost:4000/employees/'" + username + "'";
      return this.http.get<any>(url,{headers : new HttpHeaders({'Authorization':'Bearer '+sessionStorage.getItem('userToken')})});
    }
    getSubscriptionPlanDetails() :Observable<Object> {
      let url:any="http://localhost:4000/Subscription";
      return this.http.get<Object>(url);
      
  }
  getProductDetails() :Observable<Object> {
    let url:any="http://localhost:4000/Product/Products";
    return this.http.get<Object>(url);
    
  }
  getStockDetails() :Observable<Object> {
    let url:any="http://localhost:4000/Stock";
    return this.http.get<Object>(url);
  
  }
  getMutualFundsDetails() :Observable<Object> {
    let url:any="http://localhost:4000/MutualFund";
    return this.http.get<Object>(url);
  
  }
  getSectorDetails() :Observable<Object> {
    let url:any="http://localhost:4000/Sector";
    return this.http.get<Object>(url);
  
  } 
  getCountryDetails() :Observable<Object> {
    let url:any="http://localhost:4000/investor/countries";
    return this.http.get<Object>(url);
  
  }
  getStateDetails() :Observable<Object> {
    let url:any="http://localhost:4000/investor/states";
    return this.http.get<Object>(url);
  
  }
  getCityDetails() :Observable<Object> {
    let url:any="http://localhost:4000/investor/cities";
    return this.http.get<Object>(url);
  
  }

}
