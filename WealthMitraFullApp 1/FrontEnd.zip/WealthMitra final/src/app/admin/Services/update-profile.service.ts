import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UpdateProfileService {

  constructor() { }





// putDetails():Observable<Subscription>
// {
 
//   let url="https://localhost:5001/api/customers/";

//   return this.http.put<Subscription>(url);

// }
}
