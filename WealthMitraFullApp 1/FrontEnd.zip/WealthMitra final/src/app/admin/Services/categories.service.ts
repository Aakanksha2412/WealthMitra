
import { Injectable } from '@angular/core';
///***Use this For API*********
// import { HttpClient } from '@angular/common/http';
// import { Observable } from 'rxjs';
 //import{Categories} from './categories';

@Injectable({

  providedIn: 'root'

})

export class CategoriesService {

  category:any=[]

  constructor() {

  this.category=[

      {"AssetProductCategoryId":1,"ProductId":1,"CategoryName":"SmallCap","IsActive":1,"RecordCreatedBy":"Admin","RecordCreatedDate":"03/11/2021","RecordModifiedBy":"NULL","RecordModifiededDate":"NULL"},

      {"AssetProductCategoryId":2,"ProductId":2,"CategoryName":"LargeCap","IsActive":1,"RecordCreatedBy":"Admin","RecordCreatedDate":"03/11/2021","RecordModifiedBy":"NULL","RecordModifiededDate":"NULL"},

      {"AssetProductCategoryId":3,"ProductId":1,"CategoryName":"SmallCap","IsActive":1,"RecordCreatedBy":"Admin","RecordCreatedDate":"03/11/2021","RecordModifiedBy":"NULL","RecordModifiededDate":"NULL"},

      {"AssetProductCategoryId":4,"ProductId":4,"CategoryName":"MidCap","IsActive":1,"RecordCreatedBy":"Admin","RecordCreatedDate":"03/11/2021","RecordModifiedBy":"NULL","RecordModifiededDate":"NULL"},

      {"AssetProductCategoryId":5,"ProductId":3,"CategoryName":"SmallCap","IsActive":1,"RecordCreatedBy":"Admin","RecordCreatedDate":"03/11/2021","RecordModifiedBy":"NULL","RecordModifiededDate":"NULL"},

      {"AssetProductCategoryId":6,"ProductId":5,"CategoryName":"MidCap","IsActive":1,"RecordCreatedBy":"Admin","RecordCreatedDate":"03/11/2021","RecordModifiedBy":"NULL","RecordModifiededDate":"NULL"},



    ];
  }
  GetAll():any{

    return this.category;

  }
//*******Use this For API***********//

// constructor(private http:HttpClient) { }


// getDetails():Observable<Categories>
// {
 
//   let url="https://localhost:5001/api/customers/";

//   return this.http.get<Categories>(url);

// }


// putDetails():Observable<Categories>
// {
 
//   let url="https://localhost:5001/api/customers/";

//   return this.http.put<Categories>(url);

// }


// postDetails():Observable<Categories>
// {
 
//   let url="https://localhost:5001/api/customers/";

//   return this.http.post<Categories>(url);

// }



// deleteDetails():Observable<Categories>
// {
 
//   let url="https://localhost:5001/api/customers/";

//   return this.http.delete<Categories>(url);

// }
}