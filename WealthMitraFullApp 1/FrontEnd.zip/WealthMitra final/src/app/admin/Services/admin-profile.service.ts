import { Injectable } from '@angular/core';
// ///***Use this For API*********
// import { HttpClient } from '@angular/common/http';
// import { Observable } from 'rxjs';
// import { Admin } from './Admin';
//**************** */
@Injectable({
  providedIn: 'root'
})
export class AdminProfileService {

  asset:any=[]
  constructor() { this.asset=[
    {"Fname":"Ajay","Mname":"Vijay","Lname":"jakate","email":"Ajay@gmail.com","MobileNo":111111111111,"MobileNo2":1234567,"Age":31,"Pan":"PO1222HN","DOB":"2/3/1997","Gender":"Male","MaritalStatus":"Married","Address":"mumbai","Designation":"Admin","AdharID":"124352363548"}   ];
}
GetAll():any{
return this.asset;
  }



  //*******Use this For API***********//

// constructor(private http:HttpClient) { }


// getDetails():Observable<Admin>
// {
 
//   let url="https://localhost:5001/api/customers/";

//   return this.http.get<Admin>(url);

// }


// putDetails():Observable<Admin>
// {
 
//   let url="https://localhost:5001/api/customers/";

//   return this.http.put<Admin>(url);

// }


// postDetails():Observable<Admin>
// {
 
//   let url="https://localhost:5001/api/customers/";

//   return this.http.post<Admin>(url);

// }


// deleteDetails():Observable<Admin>
// {
 
//   let url="https://localhost:5001/api/customers/";

//   return this.http.delete<Admin>(url);

// }

}
