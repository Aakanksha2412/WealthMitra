import { Injectable } from '@angular/core';
///***Use this For API*********
// import { HttpClient } from '@angular/common/http';
// import { Observable } from 'rxjs';
//import { Mutualfunds} from './Mutualfunds';
//**************** */
@Injectable({
  providedIn: 'root'
})
export class MutualFundsService {

  Mf:any=[]

  constructor() {

  this.Mf=[
      {"MutualfundId":15,"MutualfundName":"ICICI fUND","SchemeCode":37289,"AssetProductCategoryName":"1","SectorName":1,"IsActive":1,"RecordCreatedBy":"Admin","RecordCreatedDate":"03/11/2021","RecordModifiedBy":"NULL","RecordModifiededDate":"NULL"},
  
      {"MutualfundId":16,"MutualfundName":"CANARA fUND","SchemeCode":16879,"AssetProductCategoryName":"1","SectorName":3,"IsActive":1,"RecordCreatedBy":"Admin","RecordCreatedDate":"03/11/2021","RecordModifiedBy":"NULL","RecordModifiededDate":"NULL"},

      {"MutualfundId":17,"MutualfundName":"HDfC fUND","SchemeCode":72819,"AssetProductCategoryName":"1","SectorName":3,"IsActive":1,"RecordCreatedBy":"Admin","RecordCreatedDate":"03/11/2021","RecordModifiedBy":"NULL","RecordModifiededDate":"NULL"},

      {"MutualfundId":18,"MutualfundName":"PNB fUND","SchemeCode":21567,"AssetProductCategoryName":"1","SectorName":2,"IsActive":1,"RecordCreatedBy":"Admin","RecordCreatedDate":"03/11/2021","RecordModifiedBy":"NULL","RecordModifiededDate":"NULL"},

      {"MutualfundId":19,"MutualfundName":"BAJAJ","SchemeCode":14531,"AssetProductCategoryName":"1","SectorName":3,"IsActive":1,"RecordCreatedBy":"Admin","RecordCreatedDate":"03/11/2021","RecordModifiedBy":"NULL","RecordModifiededDate":"NULL"}
   
    ];
  }
  GetAll():any{

    return this.Mf;

  }
  //*******Use this for API***********//

// constructor(private http:HttpClient) { }


// getDetails():Observable<Mutualfunds>
// {
 
//   let url="https://localhost:5001/api/customers/";

//   return this.http.get<Mutualfunds>(url);

// }


// putDetails():Observable<Mutualfunds>
// {
 
//   let url="https://localhost:5001/api/customers/";

//   return this.http.put<Mutualfunds>(url);

// }


// postDetails():Observable<Mutualfunds>
// {
 
//   let url="https://localhost:5001/api/customers/";

//   return this.http.post<Mutualfunds>(url);

// }



// deleteDetails():Observable<Mutualfunds>
// {
 
//   let url="https://localhost:5001/api/customers/";

//   return this.http.delete<Mutualfunds>(url);

// }
}
