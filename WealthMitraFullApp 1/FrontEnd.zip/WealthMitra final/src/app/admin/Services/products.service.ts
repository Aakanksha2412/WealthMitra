import { Injectable } from '@angular/core';
///***Use this For API*********
// import { HttpClient } from '@angular/common/http';
// import { Observable } from 'rxjs';
// import {Products } from './Products';
//**************** */
@Injectable({
  providedIn: 'root'
})
export class ProductsService {

  product:any=[]

  constructor() {

  this.product=[

      {"ProductId":1,"ProductName":"Stocks","AssetName":"1","IsActive":1,"RecordCreatedBy":"Admin","RecordCreatedDate":"03/11/2021","RecordModifiedBy":"NULL","RecordModifiededDate":"NULL"},

      {"ProductId":2,"ProductName":"DebtMF","AssetName":"2","IsActive":1,"RecordCreatedBy":"Admin","RecordCreatedDate":"03/11/2021","RecordModifiedBy":"NULL","RecordModifiededDate":"NULL"},

      {"ProductId":3,"ProductName":"LiquidMF","AssetName":"3","IsActive":1,"RecordCreatedBy":"Admin","RecordCreatedDate":"03/11/2021","RecordModifiedBy":"NULL","RecordModifiededDate":"NULL"},

      {"ProductId":4,"ProductName":"EquityMF","AssetName":"1","IsActive":1,"RecordCreatedBy":"Admin","RecordCreatedDate":"03/11/2021","RecordModifiedBy":"NULL","RecordModifiededDate":"NULL"},

      {"ProductId":5,"ProductName":"Cash","AssetName":"3","IsActive":1,"RecordCreatedBy":"Admin","RecordCreatedDate":"03/11/2021","RecordModifiedBy":"NULL","RecordModifiededDate":"NULL"},

    ];
  }
  GetAll():any{

    return this.product;

  }
  
//*******Use this For API***********//

// constructor(private http:HttpClient) { }


// getDetails():Observable<Products>
// {
 
//   let url="https://localhost:5001/api/customers/";

//   return this.http.get<Products>(url);

// }




// putDetails():Observable<Products>
// {
 
//   let url="https://localhost:5001/api/customers/";

//   return this.http.put<Products>(url);

// }


// postDetails():Observable<Products>
// {
 
//   let url="https://localhost:5001/api/customers/";

//   return this.http.post<Products>(url);

// }



// deleteDetails():Observable<Products>
// {
 
//   let url="https://localhost:5001/api/customers/";

//   return this.http.delete<Products>(url);

// }
}
