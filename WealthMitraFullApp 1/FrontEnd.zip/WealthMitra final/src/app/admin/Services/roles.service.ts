import { Injectable } from '@angular/core';
///***Use this For API*********
// import { HttpClient } from '@angular/common/http';
// import { Observable } from 'rxjs';
// import {Stocks } from './Stocks';
//**************** */
@Injectable({
  providedIn: 'root'
})
export class RolesService {
  role:any=[]
  constructor() { this.role=[
    {"Id":1,"Name":"Admin","IsActive":1,"RecordCreatedBy":"Admin","RecordCreatedDate":"","RecordModifiedBy":"","RecordModifiedDate":""},
    {"Id":2,"Name":"CEO","IsActive":1,"RecordCreatedBy":"Admin","RecordCreatedDate":"","RecordModifiedBy":"","RecordModifiedDate":""},
    {"Id":3,"Name":"Advisor","IsActive":1,"RecordCreatedBy":"Admin","RecordCreatedDate":"","RecordModifiedBy":"","RecordModifiedDate":""},
    {"Id":4,"Name":"Investor","IsActive":1,"RecordCreatedBy":"Admin","RecordCreatedDate":"","RecordModifiedBy":"","RecordModifiedDate":""},
    ];
  } 

GetAll():any{
return this.role;
}



//*******Use this For API***********//

// constructor(private http:HttpClient) { }


// getDetails():Observable<Roles>
// {
 
//   let url="https://localhost:5001/api/customers/";

//   return this.http.get<Roles>(url);

// }


// putDetails():Observable<Roles>
// {
 
//   let url="https://localhost:5001/api/customers/";

//   return this.http.put<Roles>(url);

// }


// postDetails():Observable<Roles>
// {
 
//   let url="https://localhost:5001/api/customers/";

//   return this.http.post<Roles>(url);

// }



// deleteDetails():Observable<Roles>
// {
 
//   let url="https://localhost:5001/api/customers/";

//   return this.http.delete<Roles>(url);

// }
}





