import { Injectable } from '@angular/core';
///***Use this For API*********
// import { HttpClient } from '@angular/common/http';
// import { Observable } from 'rxjs';
// import { Sector } from './Sector';
//**************** */

@Injectable({
  providedIn: 'root'
})
export class SectorsService {
  sector:any=[]
  constructor() { this.sector=[
    {"Id":1,"Name":"IT","IsActive":1,"RecordCreatedBy":"Admin","RecordCreatedDate":"","RecordModifiedBy":"Admin","RecordModifiedDate":""},
    {"Id":2,"Name":"Electronics","IsActive":1,"RecordCreatedBy":"Admin","RecordCreatedDate":"","RecordModifiedBy":"Admin","RecordModifiedDate":""},
    {"Id":3,"Name":"Finance","IsActive":1,"RecordCreatedBy":"Admin","RecordCreatedDate":"","RecordModifiedBy":"Admin","RecordModifiedDate":""},
    {"Id":4,"Name":"Oil","IsActive":1,"RecordCreatedBy":"Admin","RecordCreatedDate":"","RecordModifiedBy":"Admin","RecordModifiedDate":""}
  
    ];
   }
   GetAll():any{
    return this.sector;
    }



  //  *******Use this For API***********//

// constructor(private http:HttpClient) { }


// getDetails():Observable<Sector>
// {
 
//   let url="https://localhost:5001/api/customers/";

//   return this.http.get<Sector>(url);

// }


// putDetails():Observable<Sector>
// {
 
//   let url="https://localhost:5001/api/customers/";

//   return this.http.put<Sector>(url);

// }


// postDetails():Observable<Sector>
// {
 
//   let url="https://localhost:5001/api/customers/";

//   return this.http.post<Sector>(url);

// }



// deleteDetails():Observable<Sector>
// {
 
//   let url="https://localhost:5001/api/customers/";

//   return this.http.delete<Sector>(url);

// }
}
