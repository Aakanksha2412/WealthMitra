import { TestBed } from '@angular/core/testing';

import { SubscriptionplansService } from './subscriptionplans.service';

describe('SubscriptionplansService', () => {
  let service: SubscriptionplansService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SubscriptionplansService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
