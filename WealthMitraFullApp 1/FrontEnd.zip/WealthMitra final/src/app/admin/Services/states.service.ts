import { Injectable } from '@angular/core';
///***Use this For API*********
// import { HttpClient } from '@angular/common/http';
// import { Observable } from 'rxjs';
// import {State } from './State';
//**************** */

@Injectable({
  providedIn: 'root'
})
export class StatesService {
  state:any=[]
  constructor() { 
    this.state=[
      {"Id":1,"Name":"Maharahtra","CountryId":1,"IsActive":1,"RecordCreatedBy":"Admin","RecordCreatedDate":"","RecordModifiedBy":"Admin","RecordModifiedDate":""},
      {"Id":2,"Name":"Texas","CountryId":2,"IsActive":1,"RecordCreatedBy":"Admin","RecordCreatedDate":"","RecordModifiedBy":"Admin","RecordModifiedDate":""},
      {"Id":3,"Name":"California","CountryId":3,"IsActive":1,"RecordCreatedBy":"Admin","RecordCreatedDate":"","RecordModifiedBy":"Admin","RecordModifiedDate":""},
    
      ];
   }
   GetAll():any{
    return this.state;
    }




    
//*******Use this For API***********//

// constructor(private http:HttpClient) { }


// getDetails():Observable<State>
// {
 
//   let url="https://localhost:5001/api/customers/";

//   return this.http.get<State>(url);

// }



// putDetails():Observable<State>
// {
 
//   let url="https://localhost:5001/api/customers/";

//   return this.http.put<State>(url);

// }


// postDetails():Observable<State>
// {
 
//   let url="https://localhost:5001/api/customers/";

//   return this.http.post<State>(url);

// }



// deleteDetails():Observable<State>
// {
 
//   let url="https://localhost:5001/api/customers/";

//   return this.http.delete<State>(url);

// }



}


