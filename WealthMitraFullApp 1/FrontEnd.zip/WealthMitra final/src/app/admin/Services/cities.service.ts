import { Injectable } from '@angular/core';
///***Use this For API*********
// import { HttpClient } from '@angular/common/http';
// import { Observable } from 'rxjs';
// import { Cities } from './cities';
//**************** */
@Injectable({
  providedIn: 'root'
})
export class CitiesService {
  city:any=[]
  constructor() {   this.city=[
    {"Id":1,"Name":"Mumbai","StateId":1,"IsActive":1,"RecordCreatedBy":"Admin","RecordCreatedDate":"","RecordModifiedBy":"Admin","RecordModifiedDate":""},
    {"Id":2,"Name":"Oklahoma","StateId":2,"IsActive":1,"RecordCreatedBy":"Admin","RecordCreatedDate":"","RecordModifiedBy":"Admin","RecordModifiedDate":""},
    {"Id":3,"Name":"Nigeria","StateId":3,"IsActive":1,"RecordCreatedBy":"Admin","RecordCreatedDate":"","RecordModifiedBy":"Admin","RecordModifiedDate":""},
  
    ];
  } 

GetAll():any{
return this.city;
}


//*******Use this For API***********//

// constructor(private http:HttpClient) { }


// getDetails():Observable<Cities>
// {
 
//   let url="https://localhost:5001/api/customers/";

//   return this.http.get<Cities>(url);

// }


// putDetails():Observable<Cities>
// {
 
//   let url="https://localhost:5001/api/customers/";

//   return this.http.put<Cities>(url);

// }


// postDetails():Observable<Cities>
// {
 
//   let url="https://localhost:5001/api/customers/";

//   return this.http.post<Cities>(url);

// }



// deleteDetails():Observable<Cities>
// {
 
//   let url="https://localhost:5001/api/customers/";

//   return this.http.delete<Cities>(url);

// }


}
