import { Injectable } from '@angular/core';
///***Use this For API*********
// import { HttpClient } from '@angular/common/http';
// import { Observable } from 'rxjs';
// import {Stocks } from './Stocks';
//**************** */
@Injectable({
  providedIn: 'root'
})
export class StocksService {
  stock:any=[]

  constructor() {

  this.stock=[

      {"StockId":5,"StockName":"Coforge Ltd","SchemeCode":"COFORGE","AssetProductCategoryName":"1","SectorName":1,"IsActive":1,"RecordCreatedBy":"Admin","RecordCreatedDate":"03/11/2021","RecordModifiedBy":"NULL","RecordModifiededDate":"NULL"},

      {"StockId":6,"StockName":"Bajaj Finance","SchemeCode":"BAJAJFIN","AssetProductCategoryName":"1","SectorName":3,"IsActive":1,"RecordCreatedBy":"Admin","RecordCreatedDate":"03/11/2021","RecordModifiedBy":"NULL","RecordModifiededDate":"NULL"},

      {"StockId":7,"StockName":"Bajaj Finserv","SchemeCode":"BAJAJFINSERV","AssetProductCategoryName":"1","SectorName":3,"IsActive":1,"RecordCreatedBy":"Admin","RecordCreatedDate":"03/11/2021","RecordModifiedBy":"NULL","RecordModifiededDate":"NULL"},

      {"StockId":8,"StockName":"Swelect Energy","SchemeCode":"SWELECTES","AssetProductCategoryName":"1","SectorName":2,"IsActive":1,"RecordCreatedBy":"Admin","RecordCreatedDate":"03/11/2021","RecordModifiedBy":"NULL","RecordModifiededDate":"NULL"},

      {"StockId":9,"StockName":"Bajaj Ltd","SchemeCode":"BAJAJLTD","AssetProductCategoryName":"1","SectorName":3,"IsActive":1,"RecordCreatedBy":"Admin","RecordCreatedDate":"03/11/2021","RecordModifiedBy":"NULL","RecordModifiededDate":"NULL"}
    ];
  }
  GetAll():any{

    return this.stock;

  
  }
  
////***********use this fro Api****************//
  // stocks:any;
  // constructor(private svc:StocksService ) {}

  // ngOnInit(): void {

  //   this.svc.getDetails().subscribe(

  //     (data)=>{
  //       this.stocks=data;
  //     }
  //   )
  // }
  //************************************************** *//




  // putDetails():Observable<Stocks>
// {
 
//   let url="https://localhost:5001/api/customers/";

//   return this.http.put<Stocks>(url);

// }


// postDetails():Observable<Stocks>
// {
 
//   let url="https://localhost:5001/api/customers/";

//   return this.http.post<Stocks>(url);

// }



// deleteDetails():Observable<Stocks>
// {
 
//   let url="https://localhost:5001/api/customers/";

//   return this.http.delete<Stocks>(url);

// }
}
