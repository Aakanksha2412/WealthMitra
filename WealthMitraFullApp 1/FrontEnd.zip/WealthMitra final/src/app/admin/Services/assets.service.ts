import { Injectable } from '@angular/core';
///***Use this For API*********
// import { HttpClient } from '@angular/common/http';
// import { Observable } from 'rxjs';
// import { Assets } from './Assets';
//**************** */
@Injectable({
  providedIn: 'root'
})
export class AssetsService {
  asset:any=[]
  constructor() { this.asset=[
    {"Id":1,"Name":"Equity","IsActive":1,"RecordCreatedBy":"Admin","RecordCreatedDate":"","RecordModifiedBy":"","RecordModifiedDate":""},
    {"Id":2,"Name":"Debt","IsActive":1,"RecordCreatedBy":"Admin","RecordCreatedDate":"","RecordModifiedBy":"","RecordModifiedDate":""},
    {"Id":3,"Name":"Liquid","IsActive":1,"RecordCreatedBy":"Admin","RecordCreatedDate":"","RecordModifiedBy":"","RecordModifiedDate":""},
    ];
}
GetAll():any{
return this.asset;
  }



  //*******Use this For API***********//

// constructor(private http:HttpClient) { }


// getDetails():Observable<Assets>
// {
 
//   let url="https://localhost:5001/api/customers/";

//   return this.http.get<Assets>(url);

// }



// putDetails():Observable<Assets>
// {
 
//   let url="https://localhost:5001/api/customers/";

//   return this.http.put<Assets>(url);

// }


// postDetails():Observable<Assets>
// {
 
//   let url="https://localhost:5001/api/customers/";

//   return this.http.post<Assets>(url);

// }



// deleteDetails():Observable<Assets>
// {
 
//   let url="https://localhost:5001/api/customers/";

//   return this.http.delete<Assets>(url);

// }
}
