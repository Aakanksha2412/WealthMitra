import { Component, OnInit } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { AdminService } from '../../Services/admin.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-stocks',
  templateUrl: './stocks.component.html',
  styleUrls: ['./stocks.component.css']
})
export class StocksComponent implements OnInit {
  stocks:any=[]
  message:any;
  constructor(private svc:AdminService, private router:Router) { }

  ngOnInit(): void {
     this.getStockDetails();
  }

  getStockDetails():void{
    this.svc.getStockDetails().subscribe( 
      (usrs)=>{
        this.stocks=usrs;
        
      },
      
      (err:HttpErrorResponse)=>{
        this.message=err;
        console.log("Error Message :\n"+err);
      });
    
  
  }

  onClick(id:any){
    sessionStorage.setItem("stockId",id)
    this.router.navigateByUrl('admin-stocks-update')
  }
  

}


