import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { AdminService } from '../../Services/admin.service';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-stocks-add',
  templateUrl: './stocks-add.component.html',
  styleUrls: ['./stocks-add.component.css']
})
export class StocksAddComponent implements OnInit {
  categories:any=[];
  sectors:any=[];
  products:any=[];
  stockName:any;
  schemeCode:any;
  categoryName:any;
  productName:any;
  sectorName:any;

  public StockForm!:FormGroup;
  obj:any;
  constructor(private svc:AdminService, private http:HttpClient,private router:Router) { }

  ngOnInit(): void {
  
    this.svc.getCategoryDetails().subscribe(
      (data)=>{
        this.categories=data;
      }
    );
    this.svc.getSectorDetails().subscribe(
      (data)=>{
        this.sectors=data;
      }
    );
    this.svc.getProductDetails().subscribe(
      (data)=>{
        this.products=data;
      }
    );  
  }  

  onSubmit(form:any):void{

        this.obj={

          "StockName":form.stockName,
          "SchemeCode":form.schemeCode,
          "CategoryName":form.categoryName,
          "ProductName":form.productName,
          "SectorName":form.sectorName,
      };
    
        console.log(this.obj);
        this.http.post("http://localhost:4000/stock/addstock",this.obj).subscribe(
          (data)=>{
            console.log(data);
            alert("Uploaded Stocks Details Successfully!!");
            this.router.navigateByUrl("admin-stocks");
          },
          (err)=>{
            console.log(err);
          });
       
      }
    

}