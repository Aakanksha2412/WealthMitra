import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { AdminService } from '../../Services/admin.service';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-stocks-update',
  templateUrl: './stocks-update.component.html',
  styleUrls: ['./stocks-update.component.css']
})
export class StocksUpdateComponent implements OnInit {
  categories:any=[];
  sectors:any=[];
  stockName:any;
  schemeCode:any;
  sectorName:any;
  categoryName:any;
  productName:any;
  products:any=[];  

  public StockForm!:FormGroup;
  obj:any;
  constructor(private svc:AdminService, private http:HttpClient,private router:Router) { }

  ngOnInit(): void {
  
    this.svc.getCategoryDetails().subscribe(
      (data)=>{
        this.categories=data;
      }
    );
    this.svc.getSectorDetails().subscribe(
      (data)=>{
        this.sectors=data;
      }
    );
    this.svc.getProductDetails().subscribe(
      (data)=>{
        this.products=data;
      }
    ); 
  }  

  onSubmit(form:any):void{

    var id = sessionStorage.getItem("stockId");
    console.log(id);

        this.obj={

          "StockName":form.stockName,
          "SchemeCode":form.schemeCode,
          "SectorName":form.sectorName,
          "ProductName":form.productName,
          "CategoryName":form.categoryName,
      };
    
        console.log(this.obj);
        this.http.put("http://localhost:4000/stock/updatestock/"+id,this.obj).subscribe(
          (data)=>{
            console.log(data);
            alert("Uploaded Stock Details Successfully!!");
            this.router.navigateByUrl("admin-stocks");
          },
          (err)=>{
            console.log(err);
          });
       
      }
    
}
