import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register-employee',
  templateUrl: './register-employee.component.html',
  styleUrls: ['./register-employee.component.css']
})
export class RegisterEmployeeComponent implements OnInit {

 
  public registerForm!:FormGroup;
  constructor(private formBuilder : FormBuilder, private http : HttpClient, private router:Router) { }

  ngOnInit(): void {
    this.registerForm = this.formBuilder.group({
      FName:['',Validators.required],

      MName:['',Validators.required],

      LName:['',Validators.required],
      
      Email:['',Validators.required],
     
      MobileNo:['',Validators.required],

      PAN:['',Validators.required],

      AadharNo:['',Validators.required],

      RoleName:['',Validators.required],

      CityName:['',Validators.required],

      Password:['',Validators.required]
    })
  }


signUp(){
console.log(this.registerForm.value);
  this.http.post<any>("http://localhost:4000/Employees/employeeadd",this.registerForm.value)
  .subscribe(res=>{
    alert("Signup Successful");
    this.registerForm.reset();
    this.router.navigate(['login'])
  },err=>{
    alert("something went wrong, please fill all the fields.");
  })
}


}
