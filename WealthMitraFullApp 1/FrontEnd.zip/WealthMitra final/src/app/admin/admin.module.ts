import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminprofileComponent } from './Profile/adminprofile/adminprofile.component';
import { AssetsComponent } from './assets/assets/assets.component';
import { AssetaddComponent } from './assets/assetadd/assetadd.component';
import { AssetupdateComponent } from './assets/assetupdate/assetupdate.component';
import { CategoriesComponent } from './categories/categories/categories.component';
import { CategoryAddComponent } from './categories/category-add/category-add.component';
import { CategoryUpdateComponent } from './categories/category-update/category-update.component';
import { UpdateProfileAdminComponent } from './Profile/update-profile-admin/update-profile-admin.component';
import { CitiesComponent } from './cities/cities/cities.component';
import { CitiesaddComponent } from './cities/citiesadd/citiesadd.component';
import { CitiesupdateComponent } from './cities/citiesupdate/citiesupdate.component';
import { CountriesComponent } from './countries/countries/countries.component';
import { CountriesaddComponent } from './countries/countriesadd/countriesadd.component';
import { CountriesupdateComponent } from './countries/countriesupdate/countriesupdate.component';
import { FirstnavigationbarComponent } from './firstnavigationbar/firstnavigationbar.component';
import { MutualFundsComponent } from './mutual-funds/mutual-funds/mutual-funds.component';
import { MfaddComponent } from './mutual-funds/mfadd/mfadd.component';
import { MfupdateComponent } from './mutual-funds/mfupdate/mfupdate.component';
import { ProductsComponent } from './products/products/products.component';
import { ProductsAddComponent } from './products/products-add/products-add.component';
import { ProductsUpdateComponent } from './products/products-update/products-update.component';
import { RolesComponent } from './roles/roles/roles.component';
import { RolesaddComponent } from './roles/rolesadd/rolesadd.component';
import { RolesupdateComponent } from './roles/rolesupdate/rolesupdate.component';
import { SecondnavbarComponent } from './secondnavbar/secondnavbar.component';
import { SectorsComponent } from './sectors/sectors/sectors.component';
import { SectorsaddComponent } from './sectors/sectorsadd/sectorsadd.component';
import { SectorsupdateComponent } from './sectors/sectorsupdate/sectorsupdate.component';
import { StatesComponent } from './states/states/states.component';
import { StatesaddComponent } from './states/statesadd/statesadd.component';
import { StatesupdateComponent } from './states/statesupdate/statesupdate.component';
import { StocksComponent } from './stocks/stocks/stocks.component';
import { StocksAddComponent } from './stocks/stocks-add/stocks-add.component';
import { StocksUpdateComponent } from './stocks/stocks-update/stocks-update.component';
import { SubscriptionplansComponent } from './subscriptionplans/subscriptionplans/subscriptionplans.component';
import { SubscriptionaddComponent } from './subscriptionplans/subscriptionadd/subscriptionadd.component';
import { SubscriptionupdateComponent } from './subscriptionplans/subscriptionupdate/subscriptionupdate.component';
import { ChartsModule } from 'ng2-charts';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AdminChangepasswordComponent } from './Profile/admin-changepassword/admin-changepassword.component';
import { appRoutingModule } from '../app-routing.module';
import { RegisterEmployeeComponent } from './register-employee/register-employee.component';



@NgModule({
  declarations: [
    AdminprofileComponent,
    AssetsComponent,
    AssetaddComponent,
    AssetupdateComponent,
    CategoriesComponent,
    CategoryAddComponent,
    CategoryUpdateComponent,
    UpdateProfileAdminComponent,
    CitiesComponent,
    CitiesaddComponent,
    CitiesupdateComponent,
    CountriesComponent,
    CountriesaddComponent,
    CountriesupdateComponent,
    FirstnavigationbarComponent,
    MutualFundsComponent,
    MfaddComponent,
    MfupdateComponent,
    ProductsComponent,
    ProductsAddComponent,
    ProductsUpdateComponent,
    RolesComponent,
    RolesaddComponent,
    RolesupdateComponent,
    SecondnavbarComponent,
    SectorsComponent,
    SectorsaddComponent,
    SectorsupdateComponent,
    StatesComponent,
    StatesaddComponent,
    StatesupdateComponent,
    StocksComponent,
    StocksAddComponent,
    StocksUpdateComponent,
    SubscriptionplansComponent,
    SubscriptionaddComponent,
    SubscriptionupdateComponent,
    AdminChangepasswordComponent,
    RegisterEmployeeComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    ChartsModule,
    appRoutingModule
  ],
  exports:[
    AdminprofileComponent,
    AssetsComponent,
    AssetaddComponent,
    AssetupdateComponent,
    CategoriesComponent,
    CategoryAddComponent,
    CategoryUpdateComponent,
    UpdateProfileAdminComponent,
    CitiesComponent,
    CitiesaddComponent,
    CitiesupdateComponent,
    CountriesComponent,
    CountriesaddComponent,
    CountriesupdateComponent,
    FirstnavigationbarComponent,
    MutualFundsComponent,
    MfaddComponent,
    MfupdateComponent,
    ProductsComponent,
    ProductsAddComponent,
    ProductsUpdateComponent,
    RolesComponent,
    RolesaddComponent,
    RolesupdateComponent,
    SecondnavbarComponent,
    SectorsComponent,
    SectorsaddComponent,
    SectorsupdateComponent,
    StatesComponent,
    StatesaddComponent,
    StatesupdateComponent,
    StocksComponent,
    StocksAddComponent,
    StocksUpdateComponent,
    SubscriptionplansComponent,
    SubscriptionaddComponent,
    SubscriptionupdateComponent,
    AdminChangepasswordComponent,
    RegisterEmployeeComponent
  ]
})
export class AdminModule { }
