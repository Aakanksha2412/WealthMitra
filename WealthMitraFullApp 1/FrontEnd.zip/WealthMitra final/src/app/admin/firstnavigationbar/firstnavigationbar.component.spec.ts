import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FirstnavigationbarComponent } from './firstnavigationbar.component';

describe('FirstnavigationbarComponent', () => {
  let component: FirstnavigationbarComponent;
  let fixture: ComponentFixture<FirstnavigationbarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FirstnavigationbarComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FirstnavigationbarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
