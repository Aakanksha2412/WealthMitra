import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-firstnavigationbar',
  templateUrl: './firstnavigationbar.component.html',
  styleUrls: ['./firstnavigationbar.component.css']
})
export class FirstnavigationbarComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit(): void {
  }

  onLogout():void {

    sessionStorage.clear();

    this.router.navigateByUrl('login');

  }

}
