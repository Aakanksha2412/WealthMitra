import { Component, OnInit } from '@angular/core';
import { AdminService } from '../../Services/admin.service';
import { FormGroup } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-changepassword',
  templateUrl: './admin-changepassword.component.html',
  styleUrls: ['./admin-changepassword.component.css']
})
export class AdminChangepasswordComponent implements OnInit {

  oldPassword:any;
  newPassword:any;
  confirmPassword:any;

  public changePassword!:FormGroup;
  obj:any;
  constructor(private svc:AdminService, private http:HttpClient,private router:Router) { }

  ngOnInit(): void {
     
  }  

  onSubmit(form:any):void{

    var email = sessionStorage.getItem("userName");
    console.log(email);

        this.obj={
          "NewPassword":form.newPassword,
          "OldPassword":form.oldPassword,
          "ConfirmPassword":form.confirmPassword,
          "Email":email,
        };
    
        console.log(this.obj);
        this.http.put("http://localhost:4000/credentials/resetpassword/",this.obj).subscribe(
          (data)=>{
            console.log(data);
            alert("Changed Password Successfully!!");
            sessionStorage.removeItem('userToken');
            sessionStorage.removeItem('userName');
            sessionStorage.removeItem('InvestorId');
            this.router.navigateByUrl('login');
          },
          (err)=>{
            console.log(err);
            alert("Unsuccessful change!!!");
          });
       
      }

}
