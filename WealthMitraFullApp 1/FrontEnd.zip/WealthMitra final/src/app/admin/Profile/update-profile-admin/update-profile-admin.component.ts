import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { AdvisorDashboardService } from 'src/app/advisor/Services/advisor-dashboard.service';
import { AdminService } from '../../Services/admin.service';

@Component({
  selector: 'app-update-profile-admin',
  templateUrl: './update-profile-admin.component.html',
  styleUrls: ['./update-profile-admin.component.css']
})
export class UpdateProfileAdminComponent implements OnInit {
  
  public updateForm!:FormGroup;
  constructor(private svc:AdminService, private formBuilder : FormBuilder, private http : HttpClient, private router:Router) { }
  admin:any;
  username:any;
  obj:any;


  ngOnInit(): void {

    this.admin=this.getAdminProfile()
  }
  getAdminProfile():void{
    
    this.username = sessionStorage.getItem('userName');
    this.svc.getAdminProfileDetails(this.username).subscribe(
    (data)=>{
      this.admin = data;
      
            
    },
    (err:HttpErrorResponse)=>{
      console.log("Error Message one:\n" + err)
    }
    
    )
  }

  update(form:any):void{
    var id = sessionStorage.getItem("AdminId");
    this.obj={
      "FName": form.FName,
      "MName": form.middleName,
      "LName": form.lastName,
      "Email": form.email,
      "MobileNo": form.mobileNo,
      "AltrnateMobileNo": form.alternateMobileNo,
      "Age": form.age,
      "Pan": form.pan,
      "Gender": form.gender,
      "DOB": form.DOB,
      "MaritalStatus": form.MaritalStatus,
      "AddressLine1": form.address1,
      "AddressLine2": form.address2,
      "Pincode": form.pincode,
      "AadharNo": form.aadharNo,
      "CityName": form.cityName,
      "Experience":form.experience,
      "JoiningDate":form.JoiningDate
    }

    console.log(this.obj);
    this.http.put("http://localhost:4000/employees/updateemployee/"+id,this.obj)
  .subscribe(res=>{
    alert("Updated Profile Successful");
  
    this.router.navigate(['admin-adminprofile'])
  },err=>{
    alert("something went wrong, please fill all the fields.");
  })
}
}
