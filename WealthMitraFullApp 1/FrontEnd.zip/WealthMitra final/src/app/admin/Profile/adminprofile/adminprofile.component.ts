import { Component, OnInit } from '@angular/core';
import { AdminProfileService } from '../../Services/admin-profile.service';
import { AdminService } from '../../Services/admin.service';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-adminprofile',
  templateUrl: './adminprofile.component.html',
  styleUrls: ['./adminprofile.component.css']
})
export class AdminprofileComponent implements OnInit {

  username:any;
  admin:any;
  adminId:any;
  status:any=false;

  constructor(private svc:AdminService) { }

  ngOnInit(): void {
    this.getAdminProfile();
    
  }
  getAdminProfile():void{
    
    this.username = sessionStorage.getItem('userName');
    this.svc.getAdminProfileDetails(this.username).subscribe(
    (data)=>{
      this.admin = data;
      this.adminId= data.EmployeeId;

      sessionStorage.setItem('AdminId',this.adminId);

      this.status = true;
      
            
    },
    (err:HttpErrorResponse)=>{
      console.log("Error Message one:\n" + err)
    }
    
    );
  }
}
