import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { AdminService } from '../../Services/admin.service';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-rolesadd',
  templateUrl: './rolesadd.component.html',
  styleUrls: ['./rolesadd.component.css']
})
export class RolesaddComponent implements OnInit {
  roleName:any;
  public RoleForm!:FormGroup;
  obj:any;
  constructor(private svc:AdminService, private http:HttpClient,private router:Router) { }

  ngOnInit(): void {
  }  

  onSubmit(form:any):void{

        this.obj={
          "RoleName":form.roleName
      };
    
        console.log(this.obj);
        this.http.post("http://localhost:4000/investor/addrole",this.obj).subscribe(
          (data)=>{
            console.log(data);
            alert("Uploaded Role Details Successfully!!");
            this.router.navigateByUrl("admin-roles");
          },
          (err)=>{
            console.log(err);
          });
       
      }

}
