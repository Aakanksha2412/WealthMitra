import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RolesupdateComponent } from './rolesupdate.component';

describe('RolesupdateComponent', () => {
  let component: RolesupdateComponent;
  let fixture: ComponentFixture<RolesupdateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RolesupdateComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RolesupdateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
