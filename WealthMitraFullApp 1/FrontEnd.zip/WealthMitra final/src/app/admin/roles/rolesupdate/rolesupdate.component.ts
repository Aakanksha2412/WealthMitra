import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { AdminService } from '../../Services/admin.service';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-rolesupdate',
  templateUrl: './rolesupdate.component.html',
  styleUrls: ['./rolesupdate.component.css']
})
export class RolesupdateComponent implements OnInit {
  roleName:any;
  public RoleForm!:FormGroup;
  obj:any;
  constructor(private svc:AdminService, private http:HttpClient,private router:Router) { }

  ngOnInit(): void {
  }  

  onSubmit(form:any):void{
    var id=sessionStorage.getItem("RoleId");
    console.log(id);
        this.obj={
          "RoleName":form.roleName
      };
    
        console.log(this.obj);
        this.http.put("http://localhost:4000/investor/updateRole/"+id,this.obj).subscribe(
          (data)=>{
            console.log(data);
            alert("Uploaded Role Details Successfully!!");
            this.router.navigateByUrl("admin-roles");
          },
          (err)=>{
            console.log(err);
          });
       
      }


}
