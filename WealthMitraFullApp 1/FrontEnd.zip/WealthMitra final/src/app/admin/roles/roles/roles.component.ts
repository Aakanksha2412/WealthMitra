import { Component, OnInit } from '@angular/core';
import { AdminService } from '../../Services/admin.service';
import { HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';
@Component({
  selector: 'app-roles',
  templateUrl: './roles.component.html',
  styleUrls: ['./roles.component.css']
})
export class RolesComponent implements OnInit {
  roles : any=[] ;
  message:any;
  constructor(private svc:AdminService, private router:Router) { }

  ngOnInit(): void {
    this.getRolesDetails();
  }
  getRolesDetails():void{
    this.svc.getRolesDetails().subscribe( 
      (usrs)=>{
        this.roles=usrs;

      },
      
      (err:HttpErrorResponse)=>{
        this.message=err;
        console.log("Error Message :\n"+err);
      });
    
  
  }

  onUpdate(id:any){
    sessionStorage.setItem("RoleId",id)
    this.router.navigateByUrl('admin-rolesupdate')
  }

}