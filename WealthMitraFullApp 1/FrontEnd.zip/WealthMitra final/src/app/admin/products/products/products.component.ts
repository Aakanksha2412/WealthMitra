import { Component, OnInit } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { AdminService } from '../../Services/admin.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
  products:any=[]
  message:any;
  constructor(private svc:AdminService,private router:Router) { }

  ngOnInit(): void {
     this.getProductDetails();
  }

  getProductDetails():void{
    this.svc.getProductDetails().subscribe( 
      (usrs)=>{
        this.products=usrs;
        
      },
      
      (err:HttpErrorResponse)=>{
        this.message=err;
        console.log("Error Message :\n"+err);
      });
  }
  onClick(id:any){
    sessionStorage.setItem("productID",id)
    this.router.navigateByUrl('admin-products-update')
  }
}




