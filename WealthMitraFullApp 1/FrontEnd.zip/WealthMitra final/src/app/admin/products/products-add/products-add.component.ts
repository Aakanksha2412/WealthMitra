import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { AdminService } from '../../Services/admin.service';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-products-add',
  templateUrl: './products-add.component.html',
  styleUrls: ['./products-add.component.css']
})
export class ProductsAddComponent implements OnInit {

  assets:any=[];
  assetName:any;
  productName:any; 

  public ProductForm!:FormGroup;
  obj:any;
  constructor(private svc:AdminService, private http:HttpClient,private router:Router) { }

  ngOnInit(): void {
  
    this.svc.getAssetDetails().subscribe(
      (data)=>{
        this.assets=data;
      }
    );
  }  

  onSubmit(form:any):void{

        this.obj={
          "ProductName":form.productName,
          "AssetName":form.assetName
      };
    
        console.log(this.obj);
        this.http.post("http://localhost:4000/Product/insertproduct",this.obj).subscribe(
          (data)=>{
            console.log(data);
            alert("Uploaded Product Details Successfully!!");
            this.router.navigateByUrl("admin-products");
          },
          (err)=>{
            console.log(err);
          });
       
      }
}
