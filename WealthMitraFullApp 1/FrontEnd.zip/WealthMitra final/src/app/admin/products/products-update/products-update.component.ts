import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { AdminService } from '../../Services/admin.service';

@Component({
  selector: 'app-products-update',
  templateUrl: './products-update.component.html',
  styleUrls: ['./products-update.component.css']
})
export class ProductsUpdateComponent implements OnInit {

  assets:any=[];
  assetName:any;
  productName:any; 

  public ProductForm!:FormGroup;
  obj:any;
  constructor(private svc:AdminService, private http:HttpClient,private router:Router) { }

  ngOnInit(): void {
  
    this.svc.getAssetDetails().subscribe(
      (data)=>{
        this.assets=data;
      }
    );
  }  

  onSubmit(form:any):void{

    var id = sessionStorage.getItem("productID");
    console.log(id);
        this.obj={
          "ProductName":form.productName,
          "AssetName":form.assetName
      };
    
        console.log(this.obj);
        this.http.put("http://localhost:4000/product/updateProduct/"+id,this.obj).subscribe(
          (data)=>{
            console.log(data);
            alert("Uploaded Product Details Successfully!!");
            this.router.navigateByUrl("admin-products");
          },
          (err)=>{
            alert("Unsuccessful");
            console.log(err);
          });
       
      }
}
