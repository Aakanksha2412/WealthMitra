import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { AdvisorDashboardService } from '../Services/advisor-dashboard.service';

@Component({
  selector: 'app-advisor-stocks',
  templateUrl: './advisor-stocks.component.html',
  styleUrls: ['./advisor-stocks.component.css']
})
export class AdvisorStocksComponent implements OnInit {

  stocks:any=[];
  
  constructor(private svc:AdvisorDashboardService){

  }
  message:any;
  username:any;
  investor:any;
  advisorId:any;
  
    ngOnInit(): void {
      this.getStocksBuyInvestmentDetails();
    }
  
    getStocksBuyInvestmentDetails():void{
    
      this.username = sessionStorage.getItem('userName');
      this.svc.getAdvisorProfileDetails(this.username).subscribe(
      (data)=>{
          //Feeding InvestorId to getAssetInvestmentDetails
          this.svc.getAllStocks().subscribe( 
            (usrs)=>{
              this.stocks=usrs;
              
            },
            
            (err:HttpErrorResponse)=>{
              this.message=err;
              console.log("Error Message twqo:\n"+err);
            });
          
        
      },
      (err:HttpErrorResponse)=>{
        console.log("Error Message one:\n" + err)
      }
      
      )
    }
  



}
