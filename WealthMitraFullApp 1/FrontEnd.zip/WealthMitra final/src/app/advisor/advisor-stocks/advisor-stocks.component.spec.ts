import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdvisorStocksComponent } from './advisor-stocks.component';

describe('AdvisorStocksComponent', () => {
  let component: AdvisorStocksComponent;
  let fixture: ComponentFixture<AdvisorStocksComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdvisorStocksComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdvisorStocksComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
