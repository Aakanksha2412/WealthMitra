import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdvisorNavigationBarComponent } from './advisor-navigation-bar.component';

describe('AdvisorNavigationBarComponent', () => {
  let component: AdvisorNavigationBarComponent;
  let fixture: ComponentFixture<AdvisorNavigationBarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdvisorNavigationBarComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdvisorNavigationBarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
