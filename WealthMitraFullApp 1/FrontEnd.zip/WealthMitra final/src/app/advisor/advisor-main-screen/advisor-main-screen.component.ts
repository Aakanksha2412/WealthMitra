import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { AdvisorDashboardService } from '../Services/advisor-dashboard.service';

@Component({
  selector: 'app-advisor-main-screen',
  templateUrl: './advisor-main-screen.component.html',
  styleUrls: ['./advisor-main-screen.component.css']
})
export class AdvisorMainScreenComponent implements OnInit {

  constructor(private svc:AdvisorDashboardService) { }

  username:any;
  advisor:any;
  advisorId:any;

  profitLoss:any;
  roi:any;
  totalInvestment:any;

  
  values:any;
  message:any;
  ngOnInit(): void {
    this.getAdvisorProfileDetails();
  }

  getAdvisorProfileDetails():void{
    
    this.username = sessionStorage.getItem('userName');
    this.svc.getAdvisorProfileDetails(this.username).subscribe(
    (data)=>{

        this.advisorId = data.EmployeeId;
        sessionStorage.setItem('AdvisorId',this.advisorId);
      console.log(this.advisorId);
        //Feeding InvestorId to getAssetInvestmentDetails
        this.svc.getCalculationsofInvestorsforAdvisor(this.advisorId).subscribe( 
          (usrs)=>{
            this.values=usrs;
            var k:any;
            for(k of this.values)
            {
              this.profitLoss=k.ProfitLoss;
              this.roi=k.ROI;
              this.totalInvestment=k.TotalValueOfInvestment
            }
          },
          
          (err:HttpErrorResponse)=>{
            this.message=err;
            console.log("Error Message twqo:\n"+err);
          });
        
      
    },
    (err:HttpErrorResponse)=>{
      console.log("Error Message one:\n" + err)
    }
    
    )
  }

}
