import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdvisorMainScreenComponent } from './advisor-main-screen.component';

describe('AdvisorMainScreenComponent', () => {
  let component: AdvisorMainScreenComponent;
  let fixture: ComponentFixture<AdvisorMainScreenComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdvisorMainScreenComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdvisorMainScreenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
