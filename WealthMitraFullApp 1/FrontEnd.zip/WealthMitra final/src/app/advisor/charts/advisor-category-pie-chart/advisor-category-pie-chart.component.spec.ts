import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdvisorCategoryPieChartComponent } from './advisor-category-pie-chart.component';

describe('AdvisorCategoryPieChartComponent', () => {
  let component: AdvisorCategoryPieChartComponent;
  let fixture: ComponentFixture<AdvisorCategoryPieChartComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdvisorCategoryPieChartComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdvisorCategoryPieChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
