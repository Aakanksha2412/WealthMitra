import { Component, OnInit } from '@angular/core';
import { SingleDataSet, Label } from 'ng2-charts';
import { ChartType ,ChartOptions } from 'chart.js';
import { AdvisorDashboardService } from '../../Services/advisor-dashboard.service';
import { HttpErrorResponse } from '@angular/common/http';
@Component({
  selector: 'app-advisor-category-pie-chart',
  templateUrl: './advisor-category-pie-chart.component.html',
  styleUrls: ['./advisor-category-pie-chart.component.css']
})
export class AdvisorCategoryPieChartComponent implements OnInit {
  public pieStocksCategoryChartOptions: ChartOptions = {
    responsive: true,
  };
  //public pieAssetChartLabels: Label[] = ["equity","debt","liquid"];
  result:any=[];
  username:any;
  investor:any;
  advisorId:any;
  data:any=[];
  dataKey:any=[];
  dataValue:any=[];
  
  public pieStocksCategoryChartLabels: Label[] =this.dataKey;
  public pieStocksCategoryChartData: SingleDataSet = this.dataValue;
  public pieStocksCategoryChartType: ChartType = 'pie';
  public pieStocksCategoryChartLegend = true;
  public pieStocksCategoryChartPlugins = [];
  public pieColor: any[] = [ {
    backgroundColor: ['rgba(30, 169, 224, 0.8)',
    'rgba(255,165,0,0.9)',
    'rgba(139, 136, 136, 0.9)',
    'rgba(255, 161, 181, 0.9)',
    'rgba(255, 102, 0, 0.9)'
    ]
}]

  assets:any
  stocksCategoryInvestment:any;
  mfstocksCategoryInvestment:any;
  message:any;
  metaData:any=[];

  constructor(private svc:AdvisorDashboardService) { 
  }

  ngOnInit(): void {
    this.getAdvisorStocksCategory();
    
  }

  getAdvisorStocksCategory():void{
    
    this.username = sessionStorage.getItem('userName');
    this.svc.getAdvisorProfileDetails(this.username).subscribe(
    (data)=>{

        this.advisorId = data.EmployeeId;
        sessionStorage.setItem('AdvisorId',this.advisorId);
        //Feeding InvestorId to getAssetInvestmentDetails
        this.svc.getAdvisorStocksCategory(this.advisorId).subscribe( 
          (usrs)=>{
            this.stocksCategoryInvestment=usrs;
            var k;
            for(k of this.stocksCategoryInvestment)
            {
              // console.log(k.AssetName);
              this.dataKey.push(k.CategoryName);
              this.dataValue.push(k.totalValue)
            }
            console.log(this.dataKey);
            console.log(this.dataValue);
          },
          
          (err:HttpErrorResponse)=>{
            this.message=err;
            console.log("Error Message twqo:\n"+err);
          });
        
      
    },
    (err:HttpErrorResponse)=>{
      console.log("Error Message one:\n" + err)
    }
    
    )
  }

}
