import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ChartOptions, ChartType } from 'chart.js';
import { Label, SingleDataSet } from 'ng2-charts';
import { AdvisorDashboardService } from '../../Services/advisor-dashboard.service';

@Component({
  selector: 'app-advisormfcategorypiechart',
  templateUrl: './advisormfcategorypiechart.component.html',
  styleUrls: ['./advisormfcategorypiechart.component.css']
})
export class AdvisormfcategorypiechartComponent implements OnInit {
  
  username:any;
  investor:any;
  advisorId:any;
  datakeyMF:any=[];
  dataValueMF:any=[];
  message:any;
  mfstocksCategoryInvestment:any;
  public pieMFCategoryChartOptions: ChartOptions = {
    responsive: true,
  };
  public pieMFCategoryChartLabels: Label[] =this.datakeyMF;
    public pieMFCategoryChartData: SingleDataSet = this.dataValueMF;
    public pieMFCategoryChartType: ChartType = 'pie';
    public pieMFCategoryChartLegend = true;
    public pieMFCategoryChartPlugins = [];
    public pieMFColor: any[] = [ {
      backgroundColor: ['rgba(30, 169, 224, 0.8)',
      'rgba(255,165,0,0.9)',
      'rgba(139, 136, 136, 0.9)',
      'rgba(255, 161, 181, 0.9)',
      'rgba(255, 102, 0, 0.9)'
      ]
  }]
  constructor(private svc:AdvisorDashboardService) { }

  ngOnInit(): void {
    this.getAdvisorMutualFundsCategory();
  }

  getAdvisorMutualFundsCategory():void{
    
    this.username = sessionStorage.getItem('userName');
    this.svc.getAdvisorProfileDetails(this.username).subscribe(
    (data)=>{

        this.advisorId = data.EmployeeId;
        sessionStorage.setItem('AdvisorId',this.advisorId);
        //Feeding InvestorId to getAssetInvestmentDetails
        this.svc.getAdvisorMutualFundsCategory(this.advisorId).subscribe( 
          (usrs)=>{
            this.mfstocksCategoryInvestment=usrs;
            var k;
            for(k of this.mfstocksCategoryInvestment)
            {
              // console.log(k.AssetName);
              this.datakeyMF.push(k.CategoryName);
              this.dataValueMF.push(k.totalValue)
            }
            console.log(this.datakeyMF);
            console.log(this.dataValueMF);
          },
          
          (err:HttpErrorResponse)=>{
            this.message=err;
            console.log("Error Message twqo:\n"+err);
          });
        
      
    },
    (err:HttpErrorResponse)=>{
      console.log("Error Message one:\n" + err)
    }
    
    )
  }


}
