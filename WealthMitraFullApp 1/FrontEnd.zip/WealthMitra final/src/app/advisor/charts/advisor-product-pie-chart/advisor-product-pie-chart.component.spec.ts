import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdvisorProductPieChartComponent } from './advisor-product-pie-chart.component';

describe('AdvisorProductPieChartComponent', () => {
  let component: AdvisorProductPieChartComponent;
  let fixture: ComponentFixture<AdvisorProductPieChartComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdvisorProductPieChartComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdvisorProductPieChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
