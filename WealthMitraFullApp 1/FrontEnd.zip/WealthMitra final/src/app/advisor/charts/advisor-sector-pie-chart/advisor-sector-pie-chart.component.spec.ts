import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdvisorSectorPieChartComponent } from './advisor-sector-pie-chart.component';

describe('AdvisorSectorPieChartComponent', () => {
  let component: AdvisorSectorPieChartComponent;
  let fixture: ComponentFixture<AdvisorSectorPieChartComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdvisorSectorPieChartComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdvisorSectorPieChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
