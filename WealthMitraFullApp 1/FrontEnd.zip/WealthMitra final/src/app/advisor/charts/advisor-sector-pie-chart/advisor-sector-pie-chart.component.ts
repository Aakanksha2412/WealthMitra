import { Component, OnInit } from '@angular/core';
import { SingleDataSet, Label } from 'ng2-charts';
import { ChartType ,ChartOptions } from 'chart.js';

@Component({
  selector: 'app-advisor-sector-pie-chart',
  templateUrl: './advisor-sector-pie-chart.component.html',
  styleUrls: ['./advisor-sector-pie-chart.component.css']
})
export class AdvisorSectorPieChartComponent implements OnInit {
  public pieSectorChartOptions: ChartOptions = {
    responsive: true,
  };
  public pieSectorChartLabels: Label[] = ['It', 'Elcetronics','Health' ];
  public pieSectorChartData: SingleDataSet = [5000, 50000, 10000];
  public pieSectorChartType: ChartType = 'pie';
  public pieSectorChartLegend = true;
  public pieSectorChartPlugins = [];
  public pieColor: any[] = [ {
  backgroundColor: ['rgba(30, 169, 224, 0.8)',
    'rgba(255,165,0,0.9)',
    'rgba(139, 136, 136, 0.9)',
    'rgba(255, 161, 181, 0.9)',
    'rgba(255, 102, 0, 0.9)'
    ]
}]
  constructor() { }

  ngOnInit(): void {
  }

}

// import { Component, OnInit } from '@angular/core';
// import { SingleDataSet, Label } from 'ng2-charts';
// import { ChartType ,ChartOptions } from 'chart.js'
// import { HttpErrorResponse } from '@angular/common/http';
// import { InvestorDashboardService } from '../../Services/investor-dashboard.service';
// @Component({
//     selector: 'app-advisor-sector-pie-chart',
//     templateUrl: './advisor-sector-pie-chart.component.html',
//     styleUrls: ['./advisor-sector-pie-chart.component.css']
//   })

// export class AdvisorSectorPieChartComponent implements OnInit {
//   public pieSectorChartOptions: ChartOptions = {
//     responsive: true,
//   };
//   message:any;
//   username:any;
//   investor:any;
//   advisorId:any;
//   dataKey:any=[];
//   dataValue:any=[];
//   sectorInvestment:any;
//   public pieSectorChartData: SingleDataSet =this.dataValue;
//   public pieSectorChartLabels: Label[] = this.dataKey;
//   public pieSectorChartType: ChartType = 'pie';
//   public pieSectorChartLegend = true;
//   public pieSectorChartPlugins = [];
//   public pieColor: any[] = [ {
//     backgroundColor: ['rgba(30, 169, 224, 0.8)',
//     'rgba(255,165,0,0.9)',
//     'rgba(139, 136, 136, 0.9)',
//     'rgba(255, 161, 181, 0.9)',
//     'rgba(255, 102, 0, 0.9)'
//     ]
// }]

  

//   constructor(private svc:InvestorDashboardService) { }

//   ngOnInit(): void {
//     this.getInvestorStocksSector();
//   }

//   getInvestorStocksSector():void{
    
//     this.username = sessionStorage.getItem('userName');
//     this.svc.getInvestorProfileDetails(this.username).subscribe(
//     (data)=>{

//         this.advisorId = data.EmployeeId;
//         sessionStorage.setItem('AdvisorId',this.advisorId);
//         //Feeding InvestorId to getAssetInvestmentDetails
//         this.svc.getInvestorStocksSector(this.advisorId).subscribe( 
//           (usrs)=>{
//             this.sectorInvestment=usrs;
//             var k;
//             for(k of this.sectorInvestment)
//             {
//               // console.log(k.AssetName);
//               this.dataKey.push(k.SectorName);
//               this.dataValue.push(k.TotalValue)
//             }
//           },
          
//           (err:HttpErrorResponse)=>{
//             this.message=err;
//             console.log("Error Message twqo:\n"+err);
//           });
        
      
//     },
//     (err:HttpErrorResponse)=>{
//       console.log("Error Message one:\n" + err)
//     }
    
//     )
//   }

//   getInvestorMutualFundSector():void{
//     this.username = sessionStorage.getItem('userName');
//     this.svc.getInvestorProfileDetails(this.username).subscribe(
//     (data)=>{

//         this.advisorId = data.EmployeeId;
//         sessionStorage.setItem('InvestorId',this.advisorId);
//         //Feeding InvestorId to getAssetInvestmentDetails
//         this.svc.getInvestorStocksSector(this.advisorId).subscribe( 
//           (usrs)=>{
//             this.sectorInvestment=usrs;
//             var k;
//             for(k of this.sectorInvestment)
//             {
//               // console.log(k.AssetName);
//               this.dataKey.push(k.SectorName);
//               this.dataValue.push(k.TotalValue)
//             }
//           },
          
//           (err:HttpErrorResponse)=>{
//             this.message=err;
//             console.log("Error Message twqo:\n"+err);
//           });
        
      
//     },
//     (err:HttpErrorResponse)=>{
//       console.log("Error Message one:\n" + err)
//     }
    
//     )
//   }

// }
