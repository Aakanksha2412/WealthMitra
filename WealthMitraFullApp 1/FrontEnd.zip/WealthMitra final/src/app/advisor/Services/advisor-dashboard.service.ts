import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdvisorDashboardService {

  constructor(private http:HttpClient) { }
  getAssetAdvisorDetails(id:any) :Observable<any> {
    let url:any="http://localhost:4000/Asset/advisorasset/"+id;
    
    return this.http.get<any>(url);
  }
  
  getProductInvestmentDetails(id:any) :Observable<any> {
    let url:any="http://localhost:4000/Product/advisorProduct/"+id;
    
    return this.http.get<any>(url,{headers : new HttpHeaders({'Authorization':'Bearer '+sessionStorage.getItem('userToken')})}); 
  }
  getAdvisorProfileDetails(username:string) :Observable<any> {
    let url:any="http://localhost:4000/employees/'" + username + "'";
    return this.http.get<any>(url,{headers : new HttpHeaders({'Authorization':'Bearer '+sessionStorage.getItem('userToken')})});
  }
  
  getAdvisorStocksCategory(id:any) : Observable<any>{
    let url:any="http://localhost:4000/Category/advisorstockscategory/"+id;
    return this.http.get<any>(url,{headers : new HttpHeaders({'Authorization':'Bearer '+sessionStorage.getItem('userToken')})});
  }
  
  getAdvisorMutualFundsCategory(id:any) : Observable<any>{
    let url:any="http://localhost:4000/Category/advisormutualfundscategory/"+id;
    return this.http.get<any>(url,{headers : new HttpHeaders({'Authorization':'Bearer '+sessionStorage.getItem('userToken')})});
  }
  getCalculationsofInvestorsforAdvisor(id:any):Observable<Object>{
    let url:any="http://localhost:4000/calculation/AdvisorProfitLossROITotalValueOfInvestment/"+id;
    
    return this.http.get<Object>(url,{headers : new HttpHeaders({'Authorization':'Bearer '+sessionStorage.getItem('userToken')})}); 
  }
  
  getAdvisorStocksSector(id:any) : Observable<Object>{
    let url:any="http://localhost:4000/sector/AdvisorStocksSector/"+id;
    return this.http.get<Object>(url,{headers : new HttpHeaders({'Authorization':'Bearer '+sessionStorage.getItem('userToken')})});
  }
  getInvestorMutualFundsSector(id:any) : Observable<Object>{
    let url:any="http://localhost:4000/sector/InvestorMutualFundsSector/"+id;
    return this.http.get<Object>(url,{headers : new HttpHeaders({'Authorization':'Bearer '+sessionStorage.getItem('userToken')})});
  }
  
  getStocksBuyInvestmentDetails(id:any) : Observable<Object>{
    let url:any="http://localhost:4000/stock/investorbuystocks/"+id;
    return this.http.get<Object>(url,{headers : new HttpHeaders({'Authorization':'Bearer '+sessionStorage.getItem('userToken')})});
  }
  
  getMutualFundBuyInvestmentDetails(id:any) : Observable<Object>{
    let url:any="http://localhost:4000/mutualfund/advisorbuymutualfunds/"+id;
    return this.http.get<Object>(url,{headers : new HttpHeaders({'Authorization':'Bearer '+sessionStorage.getItem('userToken')})});
  }
  
  getAllStocks() : Observable<Object>{
    let url:any="http://localhost:4000/stock";
    return this.http.get<Object>(url,{headers : new HttpHeaders({'Authorization':'Bearer '+sessionStorage.getItem('userToken')})});
  }
  
  getAllMutualFunds() : Observable<Object>{
    let url:any="http://localhost:4000/mutualfund";
    return this.http.get<Object>(url,{headers : new HttpHeaders({'Authorization':'Bearer '+sessionStorage.getItem('userToken')})});
  }

  getInvestorsList(id:any):Observable<Object>{
    let url:any="http://localhost:4000/investor/investorsofAdvisorby/"+id;
    return this.http.get<Object>(url,{headers : new HttpHeaders({'Authorization':'Bearer '+sessionStorage.getItem('userToken')})});
  }


}
