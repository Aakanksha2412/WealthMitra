import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AdvisorInvestorListService {
  investor:any=[]
  constructor() {
    this.investor=[
      {"id":1,"firstname":"Osama","lastname":"Laden"},
      {"id":2,"firstname":"Sultan","lastname":"Mirza"},
      {"id":3,"firstname":"David","lastname":"Headly"},
      {"id":4,"firstname":"Kasab","lastname":"Khan"},
      {"id":5,"firstname":"Dawood","lastname":"Ibrahim"}
    ];
   }

   GetAll(){
     return this.investor;
   }

   // constructor(private http:HttpClient) { }


// getDetails():Observable<Investor>
// {
 
//   let url="https://localhost:5001/api/customers/";

//   return this.http.get<Investor>(url);

// }
}
