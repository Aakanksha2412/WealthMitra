import { TestBed } from '@angular/core/testing';

import { AdvisorMutualFundsService } from './advisor-mutual-funds.service';

describe('AdvisorMutualFundsService', () => {
  let service: AdvisorMutualFundsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AdvisorMutualFundsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
