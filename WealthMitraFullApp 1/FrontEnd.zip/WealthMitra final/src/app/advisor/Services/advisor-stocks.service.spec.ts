import { TestBed } from '@angular/core/testing';

import { AdvisorStocksService } from './advisor-stocks.service';

describe('AdvisorStocksService', () => {
  let service: AdvisorStocksService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AdvisorStocksService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
