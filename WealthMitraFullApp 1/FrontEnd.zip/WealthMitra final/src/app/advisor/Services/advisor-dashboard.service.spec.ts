import { TestBed } from '@angular/core/testing';

import { AdvisorDashboardService } from './advisor-dashboard.service';

describe('AdvisorDashboardService', () => {
  let service: AdvisorDashboardService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AdvisorDashboardService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
