import { TestBed } from '@angular/core/testing';

import { AdvisorInvestorListService } from './advisor-investor-list.service';

describe('AdvisorInvestorListService', () => {
  let service: AdvisorInvestorListService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AdvisorInvestorListService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
