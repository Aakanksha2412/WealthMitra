export class Investor
{
    constructor(public ID:string,public name:string)
    {

    }
}


