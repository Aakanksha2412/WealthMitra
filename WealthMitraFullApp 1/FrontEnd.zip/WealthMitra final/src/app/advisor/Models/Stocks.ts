export class Investor
{
    constructor(public name:string,public buySellPrice:string,public currentPrice:string,public quantity:string,public TotalValue:string,public ROI:string,public PL:string)
    {

    }
}

