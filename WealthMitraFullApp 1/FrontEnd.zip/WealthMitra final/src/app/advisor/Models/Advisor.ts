export class Advisor{
    constructor(public name:string,public email:string,public mnumber:string,public amnumber:string,public age:string,public pan:string,public dob:string,public gender:string,public mstatus:string,public address:string,public designation:string,public adharId:string,)
    {

    }
}

