import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdvisorChangepasswordComponent } from './advisor-changepassword.component';

describe('AdvisorChangepasswordComponent', () => {
  let component: AdvisorChangepasswordComponent;
  let fixture: ComponentFixture<AdvisorChangepasswordComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdvisorChangepasswordComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdvisorChangepasswordComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
