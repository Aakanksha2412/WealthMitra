import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { AdvisorDashboardService } from '../../Services/advisor-dashboard.service';

@Component({
  selector: 'app-advisor-changepassword',
  templateUrl: './advisor-changepassword.component.html',
  styleUrls: ['./advisor-changepassword.component.css']
})
export class AdvisorChangepasswordComponent implements OnInit {
  oldPassword:any;
  newPassword:any;
  confirmPassword:any;

  public changePassword!:FormGroup;
  obj:any;
  constructor(private svc:AdvisorDashboardService, private http:HttpClient,private router:Router) { }

  ngOnInit(): void {
     
  }  

  onSubmit(form:any):void{

    var email = sessionStorage.getItem("userName");
    console.log(email);

        this.obj={
          "NewPassword":form.newPassword,
          "OldPassword":form.oldPassword,
          "ConfirmPassword":form.confirmPassword,
          "Email":email,
        };
    
        console.log(this.obj);
        this.http.put("http://localhost:4000/credentials/resetpassword/",this.obj).subscribe(
          (data)=>{
            console.log(data);
            alert("Changed Password Successfully!!");
            sessionStorage.removeItem('userToken');
            sessionStorage.removeItem('userName');
            sessionStorage.removeItem('InvestorId');
            this.router.navigateByUrl('login');
          },
          (err)=>{
            console.log(err);
            alert("Unsuccessful change!!!");
          });
       
      }

}
