import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { AdvisorDashboardService } from '../../Services/advisor-dashboard.service';

@Component({
  selector: 'app-advisor-profile',
  templateUrl: './advisor-profile.component.html',
  styleUrls: ['./advisor-profile.component.css']
})
export class AdvisorProfileComponent implements OnInit {

  username:any;
  advisor:any=[];
  status:any=false;

  constructor(private svc:AdvisorDashboardService) { }

  ngOnInit(): void {
    this.getAdvisorProfile();
    
  }
  getAdvisorProfile():void{
    this.status = true;
    this.username = sessionStorage.getItem('userName');
    this.svc.getAdvisorProfileDetails(this.username).subscribe(
    (data)=>{
      this.advisor = data;
      
      
            
    },
    (err:HttpErrorResponse)=>{
      console.log("Error Message one:\n" + err)
    }
    
    );
  }

}
