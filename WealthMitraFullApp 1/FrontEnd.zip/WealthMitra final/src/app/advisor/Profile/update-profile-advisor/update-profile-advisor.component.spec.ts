import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateProfileAdvisorComponent } from './update-profile-advisor.component';

describe('UpdateProfileAdvisorComponent', () => {
  let component: UpdateProfileAdvisorComponent;
  let fixture: ComponentFixture<UpdateProfileAdvisorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpdateProfileAdvisorComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateProfileAdvisorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
