import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { AdvisorDashboardService } from '../Services/advisor-dashboard.service';

@Component({
  selector: 'app-advisor-mutual-funds',
  templateUrl: './advisor-mutual-funds.component.html',
  styleUrls: ['./advisor-mutual-funds.component.css']
})
export class AdvisorMutualFundsComponent implements OnInit {

  mutuals:any=[];
  
  message:any;
  username:any;
  investor:any;
  advisorId:any;
  
    ngOnInit(): void {
      this.getMutualFundBuyInvestmentDetails();
    }

    constructor(private svc:AdvisorDashboardService){

    }
  
    getMutualFundBuyInvestmentDetails():void{
    
      this.username = sessionStorage.getItem('userName');
      this.svc.getAdvisorProfileDetails(this.username).subscribe(
      (data)=>{
          //Feeding InvestorId to getAssetInvestmentDetails
          this.svc.getAllMutualFunds().subscribe( 
            (usrs)=>{
              this.mutuals=usrs;
              
            },
            
            (err:HttpErrorResponse)=>{
              this.message=err;
              console.log("Error Message twqo:\n"+err);
            });
          
        
      },
      (err:HttpErrorResponse)=>{
        console.log("Error Message one:\n" + err)
      }
      
      )
    }
}
