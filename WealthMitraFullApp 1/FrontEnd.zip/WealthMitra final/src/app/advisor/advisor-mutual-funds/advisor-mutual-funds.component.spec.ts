import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdvisorMutualFundsComponent } from './advisor-mutual-funds.component';

describe('AdvisorMutualFundsComponent', () => {
  let component: AdvisorMutualFundsComponent;
  let fixture: ComponentFixture<AdvisorMutualFundsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdvisorMutualFundsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdvisorMutualFundsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
