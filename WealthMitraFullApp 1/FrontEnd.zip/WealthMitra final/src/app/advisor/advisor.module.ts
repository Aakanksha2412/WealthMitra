import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdvisorMainScreenComponent } from './advisor-main-screen/advisor-main-screen.component';
import { AdvisorMutualFundsComponent } from './advisor-mutual-funds/advisor-mutual-funds.component';
import { AdvisorNavigationBarComponent } from './advisor-navigation-bar/advisor-navigation-bar.component';
import { AdvisorProfileComponent } from './Profile/advisor-profile/advisor-profile.component';
import { AdvisorAssetsPieChartComponent } from './charts/advisor-assets-pie-chart/advisor-assets-pie-chart.component';
import { AdvisorCategoryPieChartComponent } from './charts/advisor-category-pie-chart/advisor-category-pie-chart.component';
import { AdvisorProductPieChartComponent } from './charts/advisor-product-pie-chart/advisor-product-pie-chart.component';
import { AdvisorSectorPieChartComponent } from './charts/advisor-sector-pie-chart/advisor-sector-pie-chart.component';
import { AdvisorStocksComponent } from './advisor-stocks/advisor-stocks.component';
import { ChartsModule } from 'ng2-charts';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AdvisorChangepasswordComponent } from './Profile/advisor-changepassword/advisor-changepassword.component';
import { UpdateProfileAdvisorComponent } from './Profile/update-profile-advisor/update-profile-advisor.component';
import { AdvisorInvestorlistComponent } from './advisor-investorlist/advisor-investorlist.component';
import { appRoutingModule } from '../app-routing.module';
import { AdvisormfcategorypiechartComponent } from './charts/advisormfcategorypiechart/advisormfcategorypiechart.component';



@NgModule({
  declarations: [
    AdvisorMainScreenComponent,
    AdvisorMutualFundsComponent,
    AdvisorNavigationBarComponent,
    AdvisorProfileComponent,
    AdvisorAssetsPieChartComponent,
    AdvisorCategoryPieChartComponent,
    AdvisorProductPieChartComponent,
    AdvisorSectorPieChartComponent,
    AdvisorStocksComponent,
    AdvisorChangepasswordComponent,
    UpdateProfileAdvisorComponent,
    AdvisorInvestorlistComponent,
    AdvisormfcategorypiechartComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    ChartsModule,
    appRoutingModule
  ],
  exports:[ 
    AdvisorMainScreenComponent,
    AdvisorMutualFundsComponent,
    AdvisorNavigationBarComponent,
    AdvisorProfileComponent,
    AdvisorAssetsPieChartComponent,
    AdvisorCategoryPieChartComponent,
    AdvisorProductPieChartComponent,
    AdvisorSectorPieChartComponent,
    AdvisorStocksComponent,
    UpdateProfileAdvisorComponent,
    AdvisorInvestorlistComponent
  ]
})
export class AdvisorModule { }
