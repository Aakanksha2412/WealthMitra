import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { AdvisorDashboardService } from '../Services/advisor-dashboard.service';

@Component({
  selector: 'app-advisor-investorlist',
  templateUrl: './advisor-investorlist.component.html',
  styleUrls: ['./advisor-investorlist.component.css']
})
export class AdvisorInvestorlistComponent implements OnInit {
  username:any;
  advisor:any;
  advisorId:any;
  message:any;

  investors:any=[];

  constructor(private svc:AdvisorDashboardService){

  }

  ngOnInit(): void {
    this.getAdvisorProfileDetails();
  }

  getAdvisorProfileDetails():void{
    
    this.username = sessionStorage.getItem('userName');
    this.svc.getAdvisorProfileDetails(this.username).subscribe(
    (data)=>{

        this.advisorId = data.EmployeeId;
        sessionStorage.setItem('AdvisorId',this.advisorId);
      console.log(this.advisorId);
        //Feeding InvestorId to getAssetInvestmentDetails
        this.svc.getInvestorsList(this.advisorId).subscribe( 
          (usrs)=>{

            console.log(usrs);
            this.investors=usrs;
            
          },
          
          (err:HttpErrorResponse)=>{
            this.message=err;
            console.log("Error Message twqo:\n"+err);
          });
        
      
    },
    (err:HttpErrorResponse)=>{
      console.log("Error Message one:\n" + err)
    }
    
    )
  }



}
