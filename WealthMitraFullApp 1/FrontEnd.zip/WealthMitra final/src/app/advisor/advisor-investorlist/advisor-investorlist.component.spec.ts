import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdvisorInvestorlistComponent } from './advisor-investorlist.component';

describe('AdvisorInvestorlistComponent', () => {
  let component: AdvisorInvestorlistComponent;
  let fixture: ComponentFixture<AdvisorInvestorlistComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdvisorInvestorlistComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdvisorInvestorlistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
