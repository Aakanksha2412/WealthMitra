import { Component, OnInit } from '@angular/core';
import { SingleDataSet, Label, monkeyPatchChartJsLegend, monkeyPatchChartJsTooltip } from 'ng2-charts';
import { ChartType ,ChartOptions } from 'chart.js'
import { InvestorDashboardService } from '../Services/investor-dashboard.service';
import { HttpErrorResponse } from '@angular/common/http';


@Component({
  selector: 'app-main-screen',
  templateUrl: './main-screen.component.html',
  styleUrls: ['./main-screen.component.css']
})
export class MainScreenComponent implements OnInit {

  constructor(private svc:InvestorDashboardService) {
    
  }
  username:any;
  investor:any;
  investorId:any;

  summary:any=[];

  profitLoss:any;
  roi:any;
  totalInvestment:any;

  
  values:any;
  message:any;
  ngOnInit(): void {
    this.getInvestorProfileID();
  }

  getInvestorProfileID():void{
    
    this.username = sessionStorage.getItem('userName');
    this.svc.getInvestorProfileDetails(this.username).subscribe(
    (data)=>{

        this.investorId = data.InvestorId;
        sessionStorage.setItem('InvestorId',this.investorId);
      console.log(this.investorId);
        //Feeding InvestorId to getAssetInvestmentDetails
        this.svc.getCalculationsofInvestor(this.investorId).subscribe( 
          (usrs)=>{
            this.values=usrs;
            var k:any;
            for(k of this.values)
            {
              this.profitLoss=k.ProfitLoss;
              this.roi=k.ROI;
              this.totalInvestment=k.TotalValueOfInvestment
            }
          },
          
          (err:HttpErrorResponse)=>{
            this.message=err;
            console.log("Error Message twqo:\n"+err);
          });


        this.svc.getInvestorSummary(this.investorId).subscribe( 
            (usrs)=>{
              this.summary=usrs;
            },
            
            (err:HttpErrorResponse)=>{
              this.message=err;
              console.log("Error Message twqo:\n"+err);
        });
        
      
    },
    (err:HttpErrorResponse)=>{
      console.log("Error Message one:\n" + err)
    }
    
    )
  }

}
