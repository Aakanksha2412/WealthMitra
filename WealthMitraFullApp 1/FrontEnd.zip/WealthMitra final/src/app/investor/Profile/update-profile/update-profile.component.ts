import { Component, OnInit } from '@angular/core';
import{HttpClient, HttpErrorResponse} from '@angular/common/http';
import { FormGroup, FormBuilder,Validator, Validators } from '@angular/forms';
import {Router} from '@angular/router';
import { Investor } from '../../Models/Investor';
import { InvestorDashboardService } from '../../Services/investor-dashboard.service';

@Component({
  selector: 'app-update-profile',
  templateUrl: './update-profile.component.html',
  styleUrls: ['./update-profile.component.css']
})
export class UpdateProfileComponent implements OnInit {

  investor:any;
  username:any;
  obj:any;

  public updateForm!:FormGroup;
  constructor(private svc:InvestorDashboardService, private formBuilder : FormBuilder, private http : HttpClient, private router:Router) {  }

  ngOnInit(): void {

    this.investor=this.getInvestorProfile()
  }
  getInvestorProfile():void{
    
    this.username = sessionStorage.getItem('userName');
    this.svc.getInvestorProfileDetails(this.username).subscribe(
    (data)=>{
      this.investor = data;
      
            
    },
    (err:HttpErrorResponse)=>{
      console.log("Error Message one:\n" + err)
    }
    
    )
  }

  update(form:any):void{
    var id = sessionStorage.getItem("InvestorId");
    this.obj={
      "FName": form.FName,
      "MName": form.middleName,
      "LName": form.lastName,
      "Email": form.email,
      "MobileNo": form.mobileNo,
      "AltrnateMobileNo": form.alternateMobileNo,
      "Age": form.age,
      "Pan": form.pan,
      "Gender": form.gender,
      "DOB": form.DOB,
      "MaritalStatus": form.MaritalStatus,
      "AddressLine1": form.address1,
      "AddressLine2": form.address2,
      "Pincode": form.pincode,
      "AadharNo": form.aadharNo,
      "CityName": form.cityName,
    }

    console.log(this.obj);
    this.http.put("http://localhost:4000/investor/updateinvestor/"+id,this.obj)
  .subscribe(res=>{
    alert("Updated Profile Successful");
  
    this.router.navigate(['investor-profile'])
  },err=>{
    alert("something went wrong, please fill all the fields.");
  })
}
}
  // update(id: any, data: any): Observable<any> {
  //   return this.httpClient.put(`${this.apiUrl}/${id}`, data).pipe(
  //   catchError(this.handleError)
  //   );
  //   }

