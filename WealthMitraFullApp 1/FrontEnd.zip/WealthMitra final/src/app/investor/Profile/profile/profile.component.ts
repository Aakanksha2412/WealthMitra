import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { InvestorDashboardService } from '../../Services/investor-dashboard.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  username:any;
  investor:any;
  status:any=false;

  constructor(private svc:InvestorDashboardService) { }

  ngOnInit(): void {
    this.getInvestorProfile();
    
  }
  getInvestorProfile():void{
    this.status = true;
    
    this.username = sessionStorage.getItem('userName');
    this.svc.getInvestorProfileDetails(this.username).subscribe(
    (data)=>{
      this.investor = data;
    },
    (err:HttpErrorResponse)=>{
      console.log("Error Message one:\n" + err)
    }
    
    )
  }
}
