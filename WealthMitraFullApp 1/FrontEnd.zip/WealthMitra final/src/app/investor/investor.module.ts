import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ChangepasswordComponent } from './Profile/changepassword/changepassword.component';
import { AssetPieComponent } from './charts/asset-pie/asset-pie.component';
import { MutualFundsCategoryPieComponent } from './charts/mutual-funds-category-pie/mutual-funds-category-pie.component';
import { ProductPieComponent } from './charts/product-pie/product-pie.component';
import { StocksCategoryPieComponent } from './charts/stocks-category-pie/stocks-category-pie.component';
import { MainScreenComponent } from './main-screen/main-screen.component';
import { AddMutualFundComponent } from './mutual-fund/add-mutual-fund/add-mutual-fund.component';
import { DisplayMutualFundComponent } from './mutual-fund/display-mutual-fund/display-mutual-fund.component';
import { SectorPieChartComponent } from './charts/sector-pie-chart/sector-pie-chart.component';
import { NavigationBarComponent } from './navigation-bar/navigation-bar.component';
import { ProfileComponent } from './Profile/profile/profile.component';
import { AssetDisplayComponent } from './stock/asset-display/asset-display.component';
import { RegisterAssetsComponent } from './stock/register-assets/register-assets.component';
import { MutualFundHistoryComponent } from './transaction-history/mutual-fund-history/mutual-fund-history.component';
import { StockHistoryComponent } from './transaction-history/stock-history/stock-history.component';
import { TransactionHistoryComponent } from './transaction-history/transaction-history/transaction-history.component';
import { UpdateProfileComponent } from './Profile/update-profile/update-profile.component';
import { BuyplansComponent } from './buyplans/buyplans.component';
import { ChartsModule } from 'ng2-charts';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { appRoutingModule } from '../app-routing.module';
import { MutualfundSectorPieChartComponent } from './charts/mutualfund-sector-pie-chart/mutualfund-sector-pie-chart.component';



@NgModule({
  declarations: [
    ChangepasswordComponent,
    AssetPieComponent,
    MutualFundsCategoryPieComponent,
    ProductPieComponent,
    StocksCategoryPieComponent,
    MainScreenComponent,
    AddMutualFundComponent,
    DisplayMutualFundComponent,
    SectorPieChartComponent,
    NavigationBarComponent,
    ProfileComponent,
    AssetDisplayComponent,
    RegisterAssetsComponent,
    MutualFundHistoryComponent,
    StockHistoryComponent,
    TransactionHistoryComponent,
    UpdateProfileComponent,
    BuyplansComponent,
    MutualfundSectorPieChartComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    ChartsModule,
    appRoutingModule
  ],
  exports: [
    ChangepasswordComponent,
    AssetPieComponent,
    MutualFundsCategoryPieComponent,
    ProductPieComponent,
    StocksCategoryPieComponent,
    MainScreenComponent,
    AddMutualFundComponent,
    DisplayMutualFundComponent,
    SectorPieChartComponent,
    NavigationBarComponent,
    ProfileComponent,
    AssetDisplayComponent,
    RegisterAssetsComponent,
    MutualFundHistoryComponent,
    StockHistoryComponent,
    TransactionHistoryComponent,
    UpdateProfileComponent,
    BuyplansComponent
  ]
})
export class InvestorModule { }
