


// export class Investment{
//     constructor(public AssetName:string,public TotalValue:any
//     ){

// }
// }
export class Investor{
    constructor(
        public InvestorId:number,
        public FName:string,
        public MName:any,
        public LName:string,
        public Email:string,
        public MobileNumber:bigint,
        public AltrnateMobileNumber : bigint,
        public Age:number,
        public Pan:string,
        public Gender:string,
        public DOB:any,
        public MaritalStatus:string,
        public AddressLine1:string,
        public AddressLine2:string,
        public Pincode:any,
        public AadharNo:string,
        public CityName:string,
        public StateName:string,
        public CountryName:string,
        public SubscriptionPlanName:string,
        public PlanPurchasedDate:any,
        public PlanExpiryDate:any,
        public RecordCreatedDate:any,

    )
    {

}
}
