

export class buyplans
{
    constructor(public ID:string,public Name:string,public Price:string,public Features:string,public IsActive:string)
    {

    }
}