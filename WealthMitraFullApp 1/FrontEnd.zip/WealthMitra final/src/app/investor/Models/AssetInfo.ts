
export class Assetinfo{
        constructor(public assetID:any,public AssetName:string,public isActive:boolean,
            public recordCreatedBy:string,public recordCreatedDate:string,
            public recordModifiedBy:string,public recordModifiedDate:string
        ){

    }
}