
// export class Investment{
//     constructor(public AssetName:string,public TotalValue:any
//     ){

// }
// }
export class Investment{
    constructor(public AssetName:string,public TotalValue:any
    ){

}
}