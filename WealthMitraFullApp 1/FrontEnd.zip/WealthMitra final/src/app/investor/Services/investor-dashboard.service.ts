import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Assetinfo } from '../Models/AssetInfo';
import { Investor } from '../Models/Investor';
@Injectable({
  providedIn: 'root'
})
export class InvestorDashboardService {

  constructor(private http:HttpClient) { }

  getAssetDetails() :Observable<Assetinfo> {
    let url:any="http://localhost:4000/api/assets";
    return this.http.get<Assetinfo>(url);
  }

  getAssetInvestmentDetails(id:any) :Observable<Object> {
    let url:any="http://localhost:4000/Asset/investorasset/"+id;  
    return this.http.get<Object>(url);
  }

  getProductInvestmentDetails(id:any) :Observable<Object> {
    let url:any="http://localhost:4000/Product/investorProduct/"+id;
    return this.http.get<Object>(url,{headers : new HttpHeaders({'Authorization':'Bearer '+sessionStorage.getItem('userToken')})}); 
  }

  getInvestorProfileDetails(username:string) :Observable<any> {
    let url:any="http://localhost:4000/investor/'" + username + "'";
    return this.http.get<any>(url,{headers : new HttpHeaders({'Authorization':'Bearer '+sessionStorage.getItem('userToken')})});
  }

  getInvestorStocksCategory(id:any) : Observable<Object>{
    let url:any="http://localhost:4000/Category/investorstockscategory/"+id;
    return this.http.get<Object>(url,{headers : new HttpHeaders({'Authorization':'Bearer '+sessionStorage.getItem('userToken')})});
  }

  getInvestorMutualFundsCategory(id:any) : Observable<Object>{
    let url:any="http://localhost:4000/Category/investormutualfundscategory/"+id;
    return this.http.get<Object>(url,{headers : new HttpHeaders({'Authorization':'Bearer '+sessionStorage.getItem('userToken')})});
  }

  getCalculationsofInvestor(id:any):Observable<Object>{
    let url:any="http://localhost:4000/calculation/InvestorProfitLossROITotalValueOfInvestment/"+id;
    return this.http.get<Object>(url,{headers : new HttpHeaders({'Authorization':'Bearer '+sessionStorage.getItem('userToken')})}); 
  }

  getInvestorSummary(id:any):Observable<Object>{
    let url:any="http://localhost:4000/calculation/InvestorSummaryView/"+id;
    return this.http.get<Object>(url,{headers : new HttpHeaders({'Authorization':'Bearer '+sessionStorage.getItem('userToken')})}); 
  }

  getInvestorStocksSector(id:any) : Observable<Object>{
    let url:any="http://localhost:4000/sector/InvestorStocksSector/"+id;
    return this.http.get<Object>(url,{headers : new HttpHeaders({'Authorization':'Bearer '+sessionStorage.getItem('userToken')})});
  }
  getInvestorMutualFundsSector(id:any) : Observable<Object>{
    let url:any="http://localhost:4000/sector/InvestorMutualFundsSector/"+id;
    return this.http.get<Object>(url,{headers : new HttpHeaders({'Authorization':'Bearer '+sessionStorage.getItem('userToken')})});
  }

  getStocksBuyInvestmentDetails(id:any) : Observable<Object>{
    let url:any="http://localhost:4000/stock/investorbuystocks/"+id;
    return this.http.get<Object>(url,{headers : new HttpHeaders({'Authorization':'Bearer '+sessionStorage.getItem('userToken')})});
  }

  getMutualFundBuyInvestmentDetails(id:any) : Observable<Object>{
    let url:any="http://localhost:4000/mutualfund/investorbuymutualfunds/"+id;
    return this.http.get<Object>(url,{headers : new HttpHeaders({'Authorization':'Bearer '+sessionStorage.getItem('userToken')})});
  }

  getAllStocks() : Observable<Object>{
    let url:any="http://localhost:4000/stock";
    return this.http.get<Object>(url,{headers : new HttpHeaders({'Authorization':'Bearer '+sessionStorage.getItem('userToken')})});
  }

  getAllMutualFunds() : Observable<Object>{
    let url:any="http://localhost:4000/mutualfund";
    return this.http.get<Object>(url,{headers : new HttpHeaders({'Authorization':'Bearer '+sessionStorage.getItem('userToken')})});
  }

  getStocksHistoryOfInvestor(id:any) : Observable<Object>{
    let url:any="http://localhost:4000/stock/investorStocksHistory/"+id;
    return this.http.get<Object>(url,{headers : new HttpHeaders({'Authorization':'Bearer '+sessionStorage.getItem('userToken')})});
  }

  getMutualFundHistoryOfInvestor(id:any) : Observable<Object>{
    let url:any="http://localhost:4000/mutualfund/investormutualfundsHistory/"+id;
    return this.http.get<Object>(url,{headers : new HttpHeaders({'Authorization':'Bearer '+sessionStorage.getItem('userToken')})});
  }

}

