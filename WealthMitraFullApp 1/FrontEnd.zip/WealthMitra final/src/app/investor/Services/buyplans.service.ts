import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
///***Use this For API*********
// import { HttpClient } from '@angular/common/http';
// import { Observable } from 'rxjs';
// import { buyplans } from '../Models/buyplans';
//**************** */


@Injectable({
  providedIn: 'root'
})
export class BuyplansService {
  plan:any=[]
  constructor(private http:HttpClient) { }


GetAll():Observable<Object>{
  return this.http.get<Object>("http://localhost:4000/subscription");
    }


  
  
    //*******Use this For API***********//
  
  // constructor(private http:HttpClient) { }
  
  
  // getDetails():Observable<plans>
  // {
   
  //   let url="https://localhost:5001/api/customers/;
  
  //   return this.http.get<plans>(url);
  
  // }
  
  }