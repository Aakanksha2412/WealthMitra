import { TestBed } from '@angular/core/testing';

import { BuyplansService } from './buyplans.service';

describe('BuyplansService', () => {
  let service: BuyplansService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BuyplansService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
