import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { BuyplansService } from '../Services/buyplans.service';
import { InvestorDashboardService } from '../Services/investor-dashboard.service';

@Component({
  selector: 'app-buyplans',
  templateUrl: './buyplans.component.html',
  styleUrls: ['./buyplans.component.css']
})
export class BuyplansComponent implements OnInit {

  planId:any;
  obj:any;
 
  plans : any=[];
  username: any
  investorId: any;
  constructor(private svc:BuyplansService,private http:HttpClient,private service:InvestorDashboardService) { }

  ngOnInit(): void {
    this.svc.GetAll().subscribe(
      (data)=>{
        this.plans=data;
        console.log(data);
      }
    )
    this.getInvestorProfileID();
  }

  getInvestorProfileID():void{
    
    this.username = sessionStorage.getItem('userName');
    console.log(this.username);
    this.service.getInvestorProfileDetails(this.username).subscribe(
    (data)=>{

        this.investorId = data.InvestorId;
        sessionStorage.setItem('InvestorId',this.investorId);
        //Feeding InvestorId to getAssetInvestmentDetails
    
        })
  }

 

  

  onBuyPlan(id:any):void{
    console.log(id);
    this.obj={
      "userName":this.username,
      "InvestorId":this.investorId
    }
    this.http.put<any>("http://localhost:4000/subscription/planPurchased/"+id,this.obj).subscribe(
      (res)=>{
        alert("Updated Profile Successful");
      },
      err=>{
        alert("something went wrong, please fill all the fields.");
      }
    )
    
  }

  // this.http.put<any>("http://localhost:4000/subscription/planPurchased/"+id,this.plans).subscribe(
  //     (res)=>{
  //       alert("Updated Profile Successful");
  //     },
  //     err=>{
  //       alert("something went wrong, please fill all the fields.");
  //     }
  //   )


 ////***********use this fro Api****************//
  // plans:any;
  // constructor(private svc:BuyplansService) {}

  // ngOnInit(): void {

  //   this.svc.getDetails().subscribe(

  //     (data)=>{
  //       this.plans=data;
  //     }
  //   )
  // }
  //************************************************** *//

}
