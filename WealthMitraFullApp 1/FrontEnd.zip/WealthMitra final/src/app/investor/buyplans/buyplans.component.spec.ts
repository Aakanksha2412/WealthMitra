import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BuyplansComponent } from './buyplans.component';

describe('BuyplansComponent', () => {
  let component: BuyplansComponent;
  let fixture: ComponentFixture<BuyplansComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BuyplansComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BuyplansComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
