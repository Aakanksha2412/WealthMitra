import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HistoryService } from '../../Services/history.service';
import { InvestorDashboardService } from '../../Services/investor-dashboard.service';

@Component({
  selector: 'app-mutual-fund-history',
  templateUrl: './mutual-fund-history.component.html',
  styleUrls: ['./mutual-fund-history.component.css']
})
export class MutualFundHistoryComponent implements OnInit {

  mutualfundhistory:any;

  username:any;
  investorId:any;
  message: any;


  constructor(private svc:InvestorDashboardService,private router:Router) { }

  ngOnInit(): void {
    this.getInvestorProfileID();
  }

  getInvestorProfileID():void{
    
    this.username = sessionStorage.getItem('userName');
    this.svc.getInvestorProfileDetails(this.username).subscribe(
    (data)=>{

        this.investorId = data.InvestorId;
        sessionStorage.setItem('InvestorId',this.investorId);
        //Feeding InvestorId to getAssetInvestmentDetails
          this.svc.getMutualFundHistoryOfInvestor(this.investorId).subscribe( 
          (usrs)=>{
            this.mutualfundhistory=usrs;
            
          },
          
          (err:HttpErrorResponse)=>{
            this.message=err;
            console.log("Error Message twqo:\n"+err);
          });

    
    });
  }

  onLogout():void {

    sessionStorage.clear();

    this.router.navigateByUrl('login');

  }
}
