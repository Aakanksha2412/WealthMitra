import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HistoryService } from '../../Services/history.service';
import { InvestorDashboardService } from '../../Services/investor-dashboard.service';

@Component({
  selector: 'app-stock-history',
  templateUrl: './stock-history.component.html',
  styleUrls: ['./stock-history.component.css']
})
export class StockHistoryComponent implements OnInit {

  username:any;
  investorId:any;
  stockHistory:any;
  message: any;


  constructor(private svc:InvestorDashboardService,private router:Router) { }

  ngOnInit(): void {
    this.getInvestorProfileID();
  }

  getInvestorProfileID():void{
    
    this.username = sessionStorage.getItem('userName');
    this.svc.getInvestorProfileDetails(this.username).subscribe(
    (data)=>{

        this.investorId = data.InvestorId;
        sessionStorage.setItem('InvestorId',this.investorId);
        //Feeding InvestorId to getAssetInvestmentDetails
          this.svc.getStocksHistoryOfInvestor(this.investorId).subscribe( 
          (usrs)=>{
            this.stockHistory=usrs;
            
          },
          
          (err:HttpErrorResponse)=>{
            this.message=err;
            console.log("Error Message twqo:\n"+err);
          });

    
    });
  }

  onLogout():void {

    sessionStorage.clear();

    this.router.navigateByUrl('login');

  }



}
