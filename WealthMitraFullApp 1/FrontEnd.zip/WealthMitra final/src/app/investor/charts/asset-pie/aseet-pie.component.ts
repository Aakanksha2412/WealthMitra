
import { Component, OnInit } from '@angular/core';
import { SingleDataSet, Label, monkeyPatchChartJsLegend, monkeyPatchChartJsTooltip } from 'ng2-charts';
import { ChartType ,ChartOptions } from 'chart.js'
import { InvestorDashboardService } from '../../Services/investor-dashboard.service';
// import { Investment } from '../../Investment';
// import { Investor } from '../../Investor';
import { HttpErrorResponse } from '@angular/common/http';
import { Investment } from '../../Models/Investment';

@Component({
  selector: 'app-asset-pie',
  templateUrl: './asset-pie.component.html',
  styleUrls: ['./asset-pie.component.css']
})
export class AssetPieComponent implements OnInit {
  public pieAssetChartOptions: ChartOptions = {
    responsive: true,
  };
  //public pieAssetChartLabels: Label[] = ["equity","debt","liquid"];
  result:any=[];
  username:any;
  investor:any;
  investorId:any;
  data:any=[];
  dataKey:any=[];
  dataValue:any=[];
  public pieAssetChartLabels: Label[] =this.dataKey;
  public pieAssetChartData: SingleDataSet = this.dataValue;
  public pieAssetChartType: ChartType = 'pie';
  public pieAssetChartLegend = true;
  public pieAssetChartPlugins = [];
  public pieColor: any[] = [ {
    backgroundColor: ['rgba(30, 169, 224, 0.8)',
    'rgba(255,165,0,0.9)',
    'rgba(139, 136, 136, 0.9)',
    'rgba(255, 161, 181, 0.9)',
    'rgba(255, 102, 0, 0.9)'
    ]
}]

  assets:any
  assetInvestment:any;
  message:any;
  metaData:any=[];

  constructor(private svc:InvestorDashboardService) { 
  }

  ngOnInit(): void {
    this.getInvestorProfileID();
  }

  getInvestorProfileID():void{
    
    this.username = sessionStorage.getItem('userName');
    this.svc.getInvestorProfileDetails(this.username).subscribe(
    (data)=>{

        this.investorId = data.InvestorId;
        sessionStorage.setItem('InvestorId',this.investorId);
        //Feeding InvestorId to getAssetInvestmentDetails
        this.svc.getAssetInvestmentDetails(this.investorId).subscribe( 
          (usrs)=>{
            this.assetInvestment=usrs;
            var k:any;
            for(k of this.assetInvestment)
            {
              console.log(k.AssetName);
              this.dataKey.push(k.AssetName);
              this.dataValue.push(k.TotalValue)
            }
            console.log(this.dataKey);
            console.log(this.dataValue);
          },
          
          (err:HttpErrorResponse)=>{
            this.message=err;
            console.log("Error Message twqo:\n"+err);
          });
        
      
    },
    (err:HttpErrorResponse)=>{
      console.log("Error Message one:\n" + err)
    }
    
    )
  }

}

