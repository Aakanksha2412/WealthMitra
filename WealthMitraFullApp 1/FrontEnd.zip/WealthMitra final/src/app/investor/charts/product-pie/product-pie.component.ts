// import { Component, OnInit } from '@angular/core';
// import { SingleDataSet, Label, monkeyPatchChartJsLegend, monkeyPatchChartJsTooltip } from 'ng2-charts';
// import { ChartType ,ChartOptions } from 'chart.js'

// @Component({
//   selector: 'app-product-pie',
//   templateUrl: './product-pie.component.html',
//   styleUrls: ['./product-pie.component.css']
// })
// export class ProductPieComponent implements OnInit {
  
//   public pieProductChartOptions: ChartOptions = {
//     responsive: true,
//   };
//   public pieProductChartLabels: Label[] = ['EquityMF', 'Stock','DebtMF' ];
//   public pieProductChartData: SingleDataSet = [30000, 50000, 10000];
//   public pieProductChartType: ChartType = 'pie';
//   public pieProductChartLegend = true;
//   public pieProductChartPlugins = [];

//   constructor() { }

//   ngOnInit(): void {
//   }

// }

import { Component, OnInit } from '@angular/core';
import { SingleDataSet, Label, monkeyPatchChartJsLegend, monkeyPatchChartJsTooltip } from 'ng2-charts';
import { ChartType ,ChartOptions } from 'chart.js'
import { InvestorDashboardService } from '../../Services/investor-dashboard.service';
// import { Investment } from '../../Investment';
// import { Investor } from '../../Investor';
import { HttpErrorResponse } from '@angular/common/http';
import { Investment } from '../../Models/Investment';

@Component({
  selector: 'app-product-pie',
  templateUrl: './product-pie.component.html',
  styleUrls: ['./product-pie.component.css']
})
export class ProductPieComponent implements OnInit {
  public pieProductChartOptions: ChartOptions = {
    responsive: true,
  };
  //public pieAssetChartLabels: Label[] = ["equity","debt","liquid"];
  result:any=[];
  username:any;
  investor:any;
  investorId:any;
  data:any=[];
  dataKey:any=[];
  dataValue:any=[];
  public pieProductChartLabels: Label[] =this.dataKey;
  public pieProductChartData: SingleDataSet = this.dataValue;
  public pieProductChartType: ChartType = 'pie';
  public pieProductChartLegend = true;
  public pieProductChartPlugins = [];
  public pieColor: any[] = [ {
    backgroundColor: ['rgba(30, 169, 224, 0.8)',
    'rgba(255,165,0,0.9)',
    'rgba(139, 136, 136, 0.9)',
    'rgba(255, 161, 181, 0.9)',
    'rgba(255, 102, 0, 0.9)'
    ]
}]

  assets:any
  productInvestment:any;
  message:any;
  metaData:any=[];

  constructor(private svc:InvestorDashboardService) { 
  }

  ngOnInit(): void {
    this.getInvestorProfileID();
  }

  getInvestorProfileID():void{
    
    this.username = sessionStorage.getItem('userName');
    this.svc.getInvestorProfileDetails(this.username).subscribe(
    (data)=>{

        this.investorId = data.InvestorId;
        sessionStorage.setItem('InvestorId',this.investorId);
        //Feeding InvestorId to getAssetInvestmentDetails
        this.svc.getProductInvestmentDetails(this.investorId).subscribe( 
          (usrs)=>{
            this.productInvestment=usrs;
            var k;
            for(k of this.productInvestment)
            {
              // console.log(k.AssetName);
              this.dataKey.push(k.ProductName);
              this.dataValue.push(k.TotalValue)
            }
            console.log(this.dataKey);
            console.log(this.dataValue);
          },
          
          (err:HttpErrorResponse)=>{
            this.message=err;
            console.log("Error Message two:\n"+err);
          });
        
      
    },
    (err:HttpErrorResponse)=>{
      console.log("Error Message one:\n" + err)
    }
    
    )
  }

}


