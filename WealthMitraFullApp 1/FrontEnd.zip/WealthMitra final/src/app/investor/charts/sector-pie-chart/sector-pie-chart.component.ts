import { Component, OnInit } from '@angular/core';
import { SingleDataSet, Label } from 'ng2-charts';
import { ChartType ,ChartOptions } from 'chart.js'
import { HttpErrorResponse } from '@angular/common/http';
import { InvestorDashboardService } from '../../Services/investor-dashboard.service';
@Component({
  selector: 'app-sector-pie-chart',
  templateUrl: './sector-pie-chart.component.html',
  styleUrls: ['./sector-pie-chart.component.css']
})
export class SectorPieChartComponent implements OnInit {
  public pieSectorChartOptions: ChartOptions = {
    responsive: true,
  };
  message:any;
  username:any;
  investor:any;
  investorId:any;
  dataKey:any=[];
  dataValue:any=[];
  sectorInvestment:any;
  public pieSectorChartData: SingleDataSet =this.dataValue;
  public pieSectorChartLabels: Label[] = this.dataKey;
  public pieSectorChartType: ChartType = 'pie';
  public pieSectorChartLegend = true;
  public pieSectorChartPlugins = [];
  public pieColor: any[] = [ {
    backgroundColor: ['rgba(30, 169, 224, 0.8)',
    'rgba(255,165,0,0.9)',
    'rgba(139, 136, 136, 0.9)',
    'rgba(255, 161, 181, 0.9)',
    'rgba(255, 102, 0, 0.9)'
    ]
}]

  

  constructor(private svc:InvestorDashboardService) { }

  ngOnInit(): void {
    this.getInvestorStocksSector();
  }

  getInvestorStocksSector():void{
    
    this.username = sessionStorage.getItem('userName');
    this.svc.getInvestorProfileDetails(this.username).subscribe(
    (data)=>{

        this.investorId = data.InvestorId;
        sessionStorage.setItem('InvestorId',this.investorId);
        //Feeding InvestorId to getAssetInvestmentDetails
        this.svc.getInvestorStocksSector(this.investorId).subscribe( 
          (usrs)=>{
            this.sectorInvestment=usrs;
            var k;
            for(k of this.sectorInvestment)
            {
              // console.log(k.AssetName);
              this.dataKey.push(k.SectorName);
              this.dataValue.push(k.TotalValue)
            }
          },
          
          (err:HttpErrorResponse)=>{
            this.message=err;
            console.log("Error Message twqo:\n"+err);
          });
        
      
    },
    (err:HttpErrorResponse)=>{
      console.log("Error Message one:\n" + err)
    }
    
    )
  }

  getInvestorMutualFundSector():void{
    this.username = sessionStorage.getItem('userName');
    this.svc.getInvestorProfileDetails(this.username).subscribe(
    (data)=>{

        this.investorId = data.InvestorId;
        sessionStorage.setItem('InvestorId',this.investorId);
        //Feeding InvestorId to getAssetInvestmentDetails
        this.svc.getInvestorStocksSector(this.investorId).subscribe( 
          (usrs)=>{
            this.sectorInvestment=usrs;
            var k;
            for(k of this.sectorInvestment)
            {
              // console.log(k.AssetName);
              this.dataKey.push(k.SectorName);
              this.dataValue.push(k.TotalValue)
            }
          },
          
          (err:HttpErrorResponse)=>{
            this.message=err;
            console.log("Error Message twqo:\n"+err);
          });
        
      
    },
    (err:HttpErrorResponse)=>{
      console.log("Error Message one:\n" + err)
    }
    
    )
  }

}
