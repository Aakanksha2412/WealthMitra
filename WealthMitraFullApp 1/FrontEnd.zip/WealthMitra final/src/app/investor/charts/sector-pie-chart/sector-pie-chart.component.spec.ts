import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SectorPieChartComponent } from './sector-pie-chart.component';

describe('SectorPieChartComponent', () => {
  let component: SectorPieChartComponent;
  let fixture: ComponentFixture<SectorPieChartComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SectorPieChartComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SectorPieChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
