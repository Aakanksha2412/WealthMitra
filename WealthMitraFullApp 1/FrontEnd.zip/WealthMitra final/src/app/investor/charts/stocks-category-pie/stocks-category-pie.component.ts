// import { Component, OnInit } from '@angular/core';

// @Component({
//   selector: 'app-stocks-category-pie',
//   templateUrl: './stocks-category-pie.component.html',
//   styleUrls: ['./stocks-category-pie.component.css']
// })
// export class StocksCategoryPieComponent implements OnInit {

//   constructor() { }

//   ngOnInit(): void {
//   }



import { Component, OnInit } from '@angular/core';
import { SingleDataSet, Label, monkeyPatchChartJsLegend, monkeyPatchChartJsTooltip } from 'ng2-charts';
import { ChartType ,ChartOptions } from 'chart.js'
import { InvestorDashboardService } from '../../Services/investor-dashboard.service';
// import { Investment } from '../../Investment';
// import { Investor } from '../../Investor';
import { HttpErrorResponse } from '@angular/common/http';
// import { Investment } from '../../Investment';

@Component({
    selector: 'app-stocks-category-pie',
    templateUrl: './stocks-category-pie.component.html',
    styleUrls: ['./stocks-category-pie.component.css']
  })
export class StocksCategoryPieComponent implements OnInit {
  public pieStocksCategoryChartOptions: ChartOptions = {
    responsive: true,
  };
  //public pieAssetChartLabels: Label[] = ["equity","debt","liquid"];
  result:any=[];
  username:any;
  investor:any;
  investorId:any;
  data:any=[];
  dataKey:any=[];
  dataValue:any=[];
  public pieStocksCategoryChartLabels: Label[] =this.dataKey;
  public pieStocksCategoryChartData: SingleDataSet = this.dataValue;
  public pieStocksCategoryChartType: ChartType = 'pie';
  public pieStocksCategoryChartLegend = true;
  public pieStocksCategoryChartPlugins = [];
  public pieColor: any[] = [ {
    backgroundColor: ['rgba(30, 169, 224, 0.8)',
    'rgba(255,165,0,0.9)',
    'rgba(139, 136, 136, 0.9)',
    'rgba(255, 161, 181, 0.9)',
    'rgba(255, 102, 0, 0.9)'
    ]
}]

  assets:any
  stocksCategoryInvestment:any;
  message:any;
  metaData:any=[];

  constructor(private svc:InvestorDashboardService) { 
  }

  ngOnInit(): void {
    this.getInvestorStocksCategory();
  }

  getInvestorStocksCategory():void{
    
    this.username = sessionStorage.getItem('userName');
    this.svc.getInvestorProfileDetails(this.username).subscribe(
    (data)=>{

        this.investorId = data.InvestorId;
        sessionStorage.setItem('InvestorId',this.investorId);
        //Feeding InvestorId to getAssetInvestmentDetails
        this.svc.getInvestorStocksCategory(this.investorId).subscribe( 
          (usrs)=>{
            this.stocksCategoryInvestment=usrs;
            var k;
            for(k of this.stocksCategoryInvestment)
            {
              // console.log(k.AssetName);
              this.dataKey.push(k.CategoryName);
              this.dataValue.push(k.TotalValue)
            }
          },
          
          (err:HttpErrorResponse)=>{
            this.message=err;
            console.log("Error Message twqo:\n"+err);
          });
        
      
    },
    (err:HttpErrorResponse)=>{
      console.log("Error Message one:\n" + err)
    }
    
    )
  }

}


