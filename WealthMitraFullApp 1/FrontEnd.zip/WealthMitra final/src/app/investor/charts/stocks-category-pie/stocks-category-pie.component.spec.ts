import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StocksCategoryPieComponent } from './stocks-category-pie.component';

describe('StocksCategoryPieComponent', () => {
  let component: StocksCategoryPieComponent;
  let fixture: ComponentFixture<StocksCategoryPieComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StocksCategoryPieComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StocksCategoryPieComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
