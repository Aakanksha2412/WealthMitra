import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MutualFundsCategoryPieComponent } from './mutual-funds-category-pie.component';

describe('MutualFundsCategoryPieComponent', () => {
  let component: MutualFundsCategoryPieComponent;
  let fixture: ComponentFixture<MutualFundsCategoryPieComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MutualFundsCategoryPieComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MutualFundsCategoryPieComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
