import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MutualfundSectorPieChartComponent } from './mutualfund-sector-pie-chart.component';

describe('MutualfundSectorPieChartComponent', () => {
  let component: MutualfundSectorPieChartComponent;
  let fixture: ComponentFixture<MutualfundSectorPieChartComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MutualfundSectorPieChartComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MutualfundSectorPieChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
