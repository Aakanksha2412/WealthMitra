import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { InvestorDashboardService } from '../../Services/investor-dashboard.service';



@Component({
  selector: 'app-display-mutual-fund',
  templateUrl: './display-mutual-fund.component.html',
  styleUrls: ['./display-mutual-fund.component.css']
})
export class DisplayMutualFundComponent implements OnInit {

  constructor(private svc:InvestorDashboardService){

  }
  mutuals:any=[];
  
  message:any;
  username:any;
  investor:any;
  investorId:any;
  
    ngOnInit(): void {
      this.getMutualFundBuyInvestmentDetails();
    }
  
    getMutualFundBuyInvestmentDetails():void{
    
      this.username = sessionStorage.getItem('userName');
      this.svc.getInvestorProfileDetails(this.username).subscribe(
      (data)=>{
  
          this.investorId = data.InvestorId;
          sessionStorage.setItem('InvestorId',this.investorId);
          //Feeding InvestorId to getAssetInvestmentDetails
          this.svc.getMutualFundBuyInvestmentDetails(this.investorId).subscribe( 
            (usrs)=>{
              this.mutuals=usrs;
              
            },
            
            (err:HttpErrorResponse)=>{
              this.message=err;
              console.log("Error Message twqo:\n"+err);
            });
          
        
      },
      (err:HttpErrorResponse)=>{
        console.log("Error Message one:\n" + err)
      }
      
      )
    }
  

}
