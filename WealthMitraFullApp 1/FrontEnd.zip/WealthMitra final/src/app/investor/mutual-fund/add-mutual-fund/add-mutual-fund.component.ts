// import { Component, OnInit } from '@angular/core';

// @Component({
//   selector: 'app-add-mutual-fund',
//   templateUrl: './add-mutual-fund.component.html',
//   styleUrls: ['./add-mutual-fund.component.css']
// })
// export class AddMutualFundComponent implements OnInit {

//   constructor() { }

//   ngOnInit(): void {
//   }

// }



import { HttpClient } from '@angular/common/http';
import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { InvestorDashboardService } from '../../Services/investor-dashboard.service';

@Component({
    selector: 'app-add-mutual-fund',
    templateUrl: './add-mutual-fund.component.html',
    styleUrls: ['./add-mutual-fund.component.css']
  })
  export class AddMutualFundComponent implements OnInit {
  
  allMutualFunds:any;
  mutualFundName:any;
  schemecode:any;
  action:any;
  units:any;
  unitvalue:any;
  actionDate:any;

  allSchemeCode:any; 

  
  public transForm!:FormGroup;
  obj:any;
  constructor(private svc:InvestorDashboardService, private http:HttpClient,private router:Router) { }

  ngOnInit(): void {
    
    this.svc.getAllMutualFunds().subscribe(
      (data)=>{
        this.allMutualFunds=data;
        this.allSchemeCode = data;    
      }
    ); 
  }  

  onSubmit(form:any):void{

    var id = sessionStorage.getItem("InvestorId");
    console.log(id);

        this.obj={
          "NameOfInstrument":form.mutualFundName,
          "SchemeCode":form.schemecode,
          "Action":form.action,
          "Units":form.units,
          "UnitValue":form.unitvalue,
          "ActionDate":form.actionDate
        };
    
        console.log(this.obj);
        this.http.post("http://localhost:4000/investor/inserttransactions/"+id,this.obj).subscribe(
          (data)=>{
            console.log(data);
            alert("Uploaded Transaction Details Successfully!!");
            this.router.navigateByUrl("investor-main-screen");
          },
          (err)=>{
            console.log(err);
          });
       
      }
    
    
    

  }
  
  

  


  


