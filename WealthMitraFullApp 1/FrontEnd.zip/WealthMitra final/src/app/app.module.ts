import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { ChartsModule } from 'ng2-charts';
import { AdminModule } from './admin/admin.module';
import { AdvisorModule } from './advisor/advisor.module';
import { appRoutingModule } from './app-routing.module';

import { AppComponent } from './app.component';
import { CeoModule } from './ceo/ceo.module';
import { InvestorModule } from './investor/investor.module';
import { WelcomeModule } from './welcome/welcome.module';


@NgModule({
  declarations: [
    AppComponent
    
  ],
  imports: [
    BrowserModule,
    WelcomeModule,
    InvestorModule,
    AdvisorModule,
    AdminModule,
    CeoModule,
    ChartsModule,
    appRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
