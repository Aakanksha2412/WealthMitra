

 import{HttpClient} from '@angular/common/http';
 import {Component, OnInit } from '@angular/core';
 import {FormGroup,FormBuilder,Validators} from '@angular/forms';
 import {Router} from '@angular/router';
 import { UserValidationService } from 'src/app/user-validation.service';
 
 
 
 
 @Component({
 selector: 'app-login',
 templateUrl: './login.component.html',
 styleUrls: ['./login.component.css']
 })
 
 
 
 export class LoginComponent implements OnInit {
    user:any={
        username:"",
        password:""
      };
      userName="";
      validUser:any;
      roleId:any;
      token:any;
 
 public loginForm!:FormGroup;
 constructor(private svc:UserValidationService,private router:Router) { }
 
 
 
 ngOnInit(): void {
 }
 onValidate(form:any):void{
    console.log("Form validation event handler is invoked....");
    console.log(form.username + "  " +form.password)
    
      this.svc.validate(form.username,form.password).subscribe(
        data=>{

          console.log(data);
          this.validUser=true;
          this.roleId = data.roleId;
          this.userName = data.userName;
          sessionStorage.setItem('userToken',data.token);
          sessionStorage.setItem('userName',data.userName);
          if(this.validUser && this.roleId=='4')
          {
          this.router.navigateByUrl('investor-main-screen');
          }
          else if(this.validUser && this.roleId=='3')
          {
          this.router.navigateByUrl('advisor-main-screen');
          }
          else if(this.validUser && this.roleId=='2')
          {
          this.router.navigateByUrl('ceo-main-screen');
          }
          else if(this.validUser && this.roleId=='1')
          {
          this.router.navigateByUrl('admin-roles');
          }
        }); 
       
        
       
       
    }
 }
    

















