import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WelcomeProductsComponent } from './welcome-products.component';

describe('WelcomeProductsComponent', () => {
  let component: WelcomeProductsComponent;
  let fixture: ComponentFixture<WelcomeProductsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WelcomeProductsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WelcomeProductsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
