import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-welcome-products',
  templateUrl: './welcome-products.component.html',
  styleUrls: ['./welcome-products.component.css']
})
export class WelcomeProductsComponent implements OnInit {
  products:any=[]
  constructor() { }

  ngOnInit(): void {
  }

}
