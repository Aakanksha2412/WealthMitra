import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AboutComponent } from './about/about.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { SignupComponent } from './signup/signup.component';
import { ChartsModule } from 'ng2-charts';
import { appRoutingModule } from '../app-routing.module';
import { WelcomeProductsComponent } from './welcome-products/welcome-products.component';



@NgModule({
  declarations: [
    AboutComponent,
    ContactUsComponent,
    HomeComponent,
    LoginComponent,
    SignupComponent,
    WelcomeProductsComponent
    
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    ChartsModule,
    appRoutingModule
  ],
  exports: [
    AboutComponent,
    ContactUsComponent,
    HomeComponent,
    LoginComponent,
    SignupComponent,
    WelcomeProductsComponent
  ]
})
export class WelcomeModule { }
