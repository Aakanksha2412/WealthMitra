import { RouterModule, Routes } from "@angular/router";
import { AssetaddComponent } from "./admin/assets/assetadd/assetadd.component";
import { AssetsComponent } from "./admin/assets/assets/assets.component";
import { AssetupdateComponent } from "./admin/assets/assetupdate/assetupdate.component";
import { CategoriesComponent } from "./admin/categories/categories/categories.component";
import { CategoryAddComponent } from "./admin/categories/category-add/category-add.component";
import { CategoryUpdateComponent } from "./admin/categories/category-update/category-update.component";
import { CitiesComponent } from "./admin/cities/cities/cities.component";
import { CitiesaddComponent } from "./admin/cities/citiesadd/citiesadd.component";
import { CitiesupdateComponent } from "./admin/cities/citiesupdate/citiesupdate.component";
import { CountriesComponent } from "./admin/countries/countries/countries.component";
import { CountriesaddComponent } from "./admin/countries/countriesadd/countriesadd.component";
import { CountriesupdateComponent } from "./admin/countries/countriesupdate/countriesupdate.component";
import { FirstnavigationbarComponent } from "./admin/firstnavigationbar/firstnavigationbar.component";
import { MfaddComponent } from "./admin/mutual-funds/mfadd/mfadd.component";
import { MfupdateComponent } from "./admin/mutual-funds/mfupdate/mfupdate.component";
import { MutualFundsComponent } from "./admin/mutual-funds/mutual-funds/mutual-funds.component";
import { ProductsAddComponent } from "./admin/products/products-add/products-add.component";
import { ProductsUpdateComponent } from "./admin/products/products-update/products-update.component";
import { ProductsComponent } from "./admin/products/products/products.component";
import { AdminChangepasswordComponent } from "./admin/Profile/admin-changepassword/admin-changepassword.component";
import { AdminprofileComponent } from "./admin/Profile/adminprofile/adminprofile.component";
import { UpdateProfileAdminComponent } from "./admin/Profile/update-profile-admin/update-profile-admin.component";
import { RegisterEmployeeComponent } from "./admin/register-employee/register-employee.component";
import { RolesComponent } from "./admin/roles/roles/roles.component";
import { RolesaddComponent } from "./admin/roles/rolesadd/rolesadd.component";
import { RolesupdateComponent } from "./admin/roles/rolesupdate/rolesupdate.component";
import { SecondnavbarComponent } from "./admin/secondnavbar/secondnavbar.component";
import { SectorsComponent } from "./admin/sectors/sectors/sectors.component";
import { SectorsaddComponent } from "./admin/sectors/sectorsadd/sectorsadd.component";
import { SectorsupdateComponent } from "./admin/sectors/sectorsupdate/sectorsupdate.component";
import { StatesComponent } from "./admin/states/states/states.component";
import { StatesaddComponent } from "./admin/states/statesadd/statesadd.component";
import { StatesupdateComponent } from "./admin/states/statesupdate/statesupdate.component";
import { StocksAddComponent } from "./admin/stocks/stocks-add/stocks-add.component";
import { StocksUpdateComponent } from "./admin/stocks/stocks-update/stocks-update.component";
import { StocksComponent } from "./admin/stocks/stocks/stocks.component";
import { SubscriptionaddComponent } from "./admin/subscriptionplans/subscriptionadd/subscriptionadd.component";
import { SubscriptionplansComponent } from "./admin/subscriptionplans/subscriptionplans/subscriptionplans.component";
import { SubscriptionupdateComponent } from "./admin/subscriptionplans/subscriptionupdate/subscriptionupdate.component";
import { AdvisorInvestorlistComponent } from "./advisor/advisor-investorlist/advisor-investorlist.component";
import { AdvisorMainScreenComponent } from "./advisor/advisor-main-screen/advisor-main-screen.component";
import { AdvisorMutualFundsComponent } from "./advisor/advisor-mutual-funds/advisor-mutual-funds.component";
import { AdvisorNavigationBarComponent } from "./advisor/advisor-navigation-bar/advisor-navigation-bar.component";
import { AdvisorStocksComponent } from "./advisor/advisor-stocks/advisor-stocks.component";
import { AdvisorChangepasswordComponent } from "./advisor/Profile/advisor-changepassword/advisor-changepassword.component";
import { AdvisorProfileComponent } from "./advisor/Profile/advisor-profile/advisor-profile.component";
import { UpdateProfileAdvisorComponent } from "./advisor/Profile/update-profile-advisor/update-profile-advisor.component";
import { AuthGuard } from "./auth/auth.guard";
import { CeoMainScreenComponent } from "./ceo/ceo-main-screen/ceo-main-screen.component";
import { CeoMutualFundComponent } from "./ceo/ceo-mutual-fund/ceo-mutual-fund.component";
import { CeoNavigationBarComponent } from "./ceo/ceo-navigation-bar/ceo-navigation-bar.component";
import { CeoStocksComponent } from "./ceo/ceo-stocks/ceo-stocks.component";
import { AdvisorListComponent } from "./ceo/lists/advisor-list/advisor-list.component";
import { AdvisorsInvestorsComponent } from "./ceo/lists/advisors-investors/advisors-investors.component";
import { InvestorlistComponent } from "./ceo/lists/investorlist/investorlist.component";
import { CeoChangepasswordComponent } from "./ceo/profile/ceo-changepassword/ceo-changepassword.component";
import { CeoProfileComponent } from "./ceo/profile/ceo-profile/ceo-profile.component";
import { UpdateprofileComponent } from "./ceo/profile/updateprofile/updateprofile.component";
import { BuyplansComponent } from "./investor/buyplans/buyplans.component";
import { MainScreenComponent } from "./investor/main-screen/main-screen.component";
import { AddMutualFundComponent } from "./investor/mutual-fund/add-mutual-fund/add-mutual-fund.component";
import { DisplayMutualFundComponent } from "./investor/mutual-fund/display-mutual-fund/display-mutual-fund.component";
import { NavigationBarComponent } from "./investor/navigation-bar/navigation-bar.component";
import { ChangepasswordComponent } from "./investor/Profile/changepassword/changepassword.component";
import { ProfileComponent } from "./investor/Profile/profile/profile.component";
import { UpdateProfileComponent } from "./investor/Profile/update-profile/update-profile.component";
import { AssetDisplayComponent } from "./investor/stock/asset-display/asset-display.component";
import { RegisterAssetsComponent } from "./investor/stock/register-assets/register-assets.component";
import { MutualFundHistoryComponent } from "./investor/transaction-history/mutual-fund-history/mutual-fund-history.component";
import { StockHistoryComponent } from "./investor/transaction-history/stock-history/stock-history.component";
import { TransactionHistoryComponent } from "./investor/transaction-history/transaction-history/transaction-history.component";
import { AboutComponent } from "./welcome/about/about.component";
import { ContactUsComponent } from "./welcome/contact-us/contact-us.component";
import { HomeComponent } from "./welcome/home/home.component";
import { LoginComponent } from "./welcome/login/login.component";
import { SignupComponent } from "./welcome/signup/signup.component";
import { WelcomeProductsComponent } from "./welcome/welcome-products/welcome-products.component";



const routes: Routes = [

    //welcome Module Routing
    { path: 'home', component: HomeComponent},
    { path: 'about', component: AboutComponent},
    { path: 'contactus', component: ContactUsComponent},
    { path: 'login', component: LoginComponent},
    { path: 'products', component: WelcomeProductsComponent},
    { path: 'signup', component: SignupComponent},
    //investor Module Routing
    { path: 'investor-buyplans', component: BuyplansComponent},
    { path: 'investor-main-screen', component: MainScreenComponent,canActivate:[AuthGuard]},
    { path: 'investor-add-mutual-fund', component: AddMutualFundComponent,canActivate:[AuthGuard]},
    { path: 'investor-display-mutual-fund', component: DisplayMutualFundComponent,canActivate:[AuthGuard]},
    { path: 'investor-navigation-bar', component: NavigationBarComponent},
    { path: 'investor-changepassword', component: ChangepasswordComponent,canActivate:[AuthGuard]},
    { path: 'investor-profile', component: ProfileComponent,canActivate:[AuthGuard]},
    { path: 'investor-update-profile', component: UpdateProfileComponent,canActivate:[AuthGuard]},
    { path: 'investor-asset-display', component: AssetDisplayComponent,canActivate:[AuthGuard]},
    { path: 'investor-register-assets', component: RegisterAssetsComponent,canActivate:[AuthGuard]},
    { path: 'investor-mutual-fund-history', component: MutualFundHistoryComponent,canActivate:[AuthGuard]},
    { path: 'investor-stock-history', component: StockHistoryComponent,canActivate:[AuthGuard]},
    { path: 'investor-transaction-history', component: TransactionHistoryComponent,canActivate:[AuthGuard]},
    //ceo Module Routing
    { path: 'ceo-main-screen', component: CeoMainScreenComponent,canActivate:[AuthGuard]},
    { path: 'ceo-mutual-fund', component: CeoMutualFundComponent,canActivate:[AuthGuard]},
    { path: 'ceo-navigation-bar', component: CeoNavigationBarComponent,canActivate:[AuthGuard]},
    { path: 'ceo-stocks', component: CeoStocksComponent,canActivate:[AuthGuard]},
    { path: 'ceo-advisor-list', component: AdvisorListComponent,canActivate:[AuthGuard]},
    { path: 'ceo-advisors-investors', component: AdvisorsInvestorsComponent,canActivate:[AuthGuard]},
    { path: 'ceo-investorlist', component: InvestorlistComponent,canActivate:[AuthGuard]},
    { path: 'ceo-profile', component: CeoProfileComponent,canActivate:[AuthGuard]},
    { path: 'ceo-changepassword', component: CeoChangepasswordComponent,canActivate:[AuthGuard]},
    { path: 'ceo-updateprofile', component: UpdateprofileComponent,canActivate:[AuthGuard]},
    //advisor Module Routing
    { path: 'advisor-main-screen', component: AdvisorMainScreenComponent,canActivate:[AuthGuard]},
    { path: 'advisor-mutual-funds', component: AdvisorMutualFundsComponent,canActivate:[AuthGuard]},
    { path: 'advisor-navigationbar', component: AdvisorNavigationBarComponent,canActivate:[AuthGuard]},
    { path: 'advisor-stocks', component: AdvisorStocksComponent,canActivate:[AuthGuard]},
    { path: 'advisor-investorlist', component: AdvisorInvestorlistComponent,canActivate:[AuthGuard]},
    { path: 'advisor-changepassword', component: AdvisorChangepasswordComponent,canActivate:[AuthGuard]},
    { path: 'advisor-profile', component: AdvisorProfileComponent,canActivate:[AuthGuard]},
    { path: 'advisor-update-profile', component: UpdateProfileAdvisorComponent,canActivate:[AuthGuard]},
    //admin Module Routing
    { path: 'admin-assetadd', component: AssetaddComponent,canActivate:[AuthGuard]},
    { path: 'admin-assets', component: AssetsComponent,canActivate:[AuthGuard]},
    { path: 'admin-assetupdate', component: AssetupdateComponent,canActivate:[AuthGuard]},
    { path: 'admin-categories', component: CategoriesComponent,canActivate:[AuthGuard]},
    { path: 'admin-category-add', component: CategoryAddComponent,canActivate:[AuthGuard]},
    { path: 'admin-category-update', component: CategoryUpdateComponent,canActivate:[AuthGuard]},
    { path: 'admin-cities', component: CitiesComponent,canActivate:[AuthGuard]},
    { path: 'admin-citiesadd', component: CitiesaddComponent,canActivate:[AuthGuard]},
    { path: 'admin-citiesupdate', component: CitiesupdateComponent,canActivate:[AuthGuard]},
    { path: 'admin-countries', component: CountriesComponent,canActivate:[AuthGuard]},
    { path: 'admin-countriesadd', component: CountriesaddComponent,canActivate:[AuthGuard]},
    { path: 'admin-countriesupdate', component: CountriesupdateComponent,canActivate:[AuthGuard]},
    { path: 'admin-firstnavigation', component: FirstnavigationbarComponent,canActivate:[AuthGuard]},
    { path: 'admin-mfadd', component: MfaddComponent,canActivate:[AuthGuard]},
    { path: 'admin-mfupdate', component: MfupdateComponent,canActivate:[AuthGuard]},
    { path: 'admin-mutual-funds', component: MutualFundsComponent,canActivate:[AuthGuard]},
    { path: 'admin-products', component: ProductsComponent,canActivate:[AuthGuard]},
    { path: 'admin-products-add', component: ProductsAddComponent,canActivate:[AuthGuard]},
    { path: 'admin-products-update', component: ProductsUpdateComponent,canActivate:[AuthGuard]},
    { path: 'admin-changepassword', component: AdminChangepasswordComponent,canActivate:[AuthGuard]},
    { path: 'admin-adminprofile', component: AdminprofileComponent,canActivate:[AuthGuard]},
    { path: 'admin-update-profile-admin', component: UpdateProfileAdminComponent,canActivate:[AuthGuard]},
    { path: 'admin-roles', component: RolesComponent,canActivate:[AuthGuard]},
    { path: 'admin-rolesadd', component: RolesaddComponent,canActivate:[AuthGuard]},
    { path: 'admin-rolesupdate', component: RolesupdateComponent,canActivate:[AuthGuard]},
    { path: 'admin-secondnavbar', component: SecondnavbarComponent,canActivate:[AuthGuard]},
    { path: 'admin-sectors', component: SectorsComponent,canActivate:[AuthGuard]},
    { path: 'admin-sectorsadd', component: SectorsaddComponent,canActivate:[AuthGuard]},
    { path: 'admin-sectorsupdate', component: SectorsupdateComponent,canActivate:[AuthGuard]},
    { path: 'admin-states', component: StatesComponent,canActivate:[AuthGuard]},
    { path: 'admin-statesadd', component: StatesaddComponent,canActivate:[AuthGuard]},
    { path: 'admin-statesupdate', component: StatesupdateComponent,canActivate:[AuthGuard]},
    { path: 'admin-stocks', component: StocksComponent,canActivate:[AuthGuard]},
    { path: 'admin-stocks-add', component: StocksAddComponent,canActivate:[AuthGuard]},
    { path: 'admin-stocks-update', component: StocksUpdateComponent,canActivate:[AuthGuard]},
    { path: 'admin-subscriptionplans', component: SubscriptionplansComponent,canActivate:[AuthGuard]},
    { path: 'admin-subscriptionplansadd', component: SubscriptionaddComponent,canActivate:[AuthGuard]},
    { path: 'admin-subscriptionplansupdate', component: SubscriptionupdateComponent,canActivate:[AuthGuard]},
    { path: 'register-employee' , component:RegisterEmployeeComponent,canActivate:[AuthGuard]},
    { path: '', redirectTo: 'home' , pathMatch: 'full'}


]







export const appRoutingModule = RouterModule.forRoot(routes);


export class FormsReactiveModule {}


