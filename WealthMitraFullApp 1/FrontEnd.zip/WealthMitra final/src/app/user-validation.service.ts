import { HttpClient, HttpHeaders } from '@angular/common/http';

import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';



@Injectable({

  providedIn: 'root'

})

export class UserValidationService {

  constructor(private http:HttpClient) { }

  
  validate(username:string,password:string):Observable<any>{
    
    let  credentials:any={
                            "username":username,
                            "password":password
                        };
    // return this.http.post("https://localhost:5001/Users/authenticate",credentials);
    // var reqHeader = new HttpHeaders({'Content-Type':'application/x-www-urlencoded'});
    
    return this.http.post("http://localhost:4000/Users/authenticate",credentials);
  }

  // getAllCred()
  // {
  //   return this.http.get("http://localhost:4000/Users"
  //   ,{headers : new HttpHeaders({'Authorization':'Bearer '+sessionStorage.getItem('userToken')})});
  // }

}