import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Admin } from '../Models/Admin';
import { Advisors } from '../Models/Advisors';
import { AdvisorsInvestor } from '../Models/AdvisorsInvestor';
import { Investors } from '../Models/Investors';
import { Mutualfunds } from '../Models/Mutualfunds';
import { Stocks } from '../Models/Stocks';

@Injectable({
  providedIn: 'root'
})
export class CeoService {

  
constructor(private http:HttpClient) { }


getCEOProfileDetails(username:string) :Observable<any> {
  let url:any="http://localhost:4000/Employees/'" + username + "'";
  return this.http.get<any>(url,{headers : new HttpHeaders({'Authorization':'Bearer '+sessionStorage.getItem('userToken')})});
}

getCalculationsofCEO() :Observable<any> 

{
  let url:any="http://localhost:4000/calculation/CEOProfitLossROITotalValueOfInvestment";
  return this.http.get<any>(url,{headers : new HttpHeaders({'Authorization':'Bearer '+sessionStorage.getItem('userToken')})});
}

getAssetInvestmentDetails() :Observable<any> {
  let url:any="http://localhost:4000/Asset/ceoasset";
  // console.log(id);
  
  return this.http.get<Object>(url);
}
getProductInvestmentDetails() :Observable<any> {
  let url:any="http://localhost:4000/Product/ceoproduct";
  
  return this.http.get<Object>(url);
}

getCeoStocksCategory() :Observable<any> {
  let url:any="http://localhost:4000/Category/ceostockscategory";
  
  return this.http.get<Object>(url);
}
getCeoMutualFundsCategory() :Observable<any> {
  let url:any="http://localhost:4000/Category/ceomutualfundscategory";
  
  return this.http.get<Object>(url);
}
getAdvisorsList():Observable<any>{
  let url:any="http://localhost:4000/employees";
  return this.http.get<Object>(url);
}

getAdvisorInvestors(id:any):Observable<any>{
  let url:any="http://localhost:4000/investor/investorsofAdvisorby/"+id;
  return this.http.get<Object>(url);
}

getInvestorsList():Observable<any>{
  let url:any="http://localhost:4000/Investor/allinvestors";
  return this.http.get<Object>(url);
}
getStockDetails() :Observable<any>
{
  let url:any="http://localhost:4000/Stock";
  return this.http.get<Object>(url);
}
  getMutualFundsDetails() :Observable<any>
  {
  let url:any="http://localhost:4000/MutualFund";
  return this.http.get<Object>(url);
  }
}


