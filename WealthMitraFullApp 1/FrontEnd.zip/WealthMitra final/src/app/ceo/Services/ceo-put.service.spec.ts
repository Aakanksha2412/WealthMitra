import { TestBed } from '@angular/core/testing';

import { CeoPutService } from './ceo-put.service';

describe('CeoPutService', () => {
  let service: CeoPutService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CeoPutService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
