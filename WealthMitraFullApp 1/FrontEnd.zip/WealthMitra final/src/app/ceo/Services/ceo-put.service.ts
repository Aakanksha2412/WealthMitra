import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class CeoPutService {
  errorMessage:any;


  constructor(private http:HttpClient) { }
  
  
  
  
  changePassword() {
    const body = { title: 'Angular PUT Request ' };
    this.http.put<any>('https://jsonplaceholder.typicode.com/invalid-url', body)
        .subscribe({
            next: data => {
                this.postId = data.id;
            },
            error: error => {
                this.errorMessage = error.message;
                console.error('There was an error!', error);
            }
        });
      }
  
  
  UpdateProfile() {
    const body = { title: 'Angular PUT Request' };
    this.http.put<any>('https://jsonplaceholder.typicode.com/invalid-url', body)
        .subscribe({
            next: data => {
                this.postId = data.id;
            },
            error: error => {
                this.errorMessage = error.message;
                console.error('There was an error!', error);
            }
        });
      }
  
}
