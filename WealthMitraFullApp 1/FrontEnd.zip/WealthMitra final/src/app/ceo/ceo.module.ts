import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdvisorListComponent } from './lists/advisor-list/advisor-list.component';
import { AdvisorsInvestorsComponent } from './lists/advisors-investors/advisors-investors.component';
import { CeoMainScreenComponent } from './ceo-main-screen/ceo-main-screen.component';
import { CeoMutualFundComponent } from './ceo-mutual-fund/ceo-mutual-fund.component';
import { CeoNavigationBarComponent } from './ceo-navigation-bar/ceo-navigation-bar.component';
import { CeoProfileComponent } from './profile/ceo-profile/ceo-profile.component';
import { UpdateprofileComponent } from './profile/updateprofile/updateprofile.component';
import { CeoAssetPieChartComponent } from './charts/ceo-asset-pie-chart/ceo-asset-pie-chart.component';
import { CeoCategoryPieChartComponent } from './charts/ceo-category-pie-chart/ceo-category-pie-chart.component';
import { CeoProductPieChartComponent } from './charts/ceo-product-pie-chart/ceo-product-pie-chart.component';
// import { CeoSectorPieChartComponent } from './charts/ceo-sector-pie-chart/ceo-sector-pie-chart.component';
import { InvestorlistComponent } from './lists/investorlist/investorlist.component';
import { CeoStocksComponent } from './ceo-stocks/ceo-stocks.component';
import { ChartsModule } from 'ng2-charts';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CeoChangepasswordComponent } from './profile/ceo-changepassword/ceo-changepassword.component';
import { appRoutingModule } from '../app-routing.module';
import { CeoMfCategoryPieComponent } from './charts/ceo-mf-category-pie/ceo-mf-category-pie.component';


@NgModule({
  declarations: [
    AdvisorListComponent,
    AdvisorsInvestorsComponent,
    CeoMainScreenComponent,
    CeoMutualFundComponent,
    CeoNavigationBarComponent,
    CeoProfileComponent,
    UpdateprofileComponent,
    CeoAssetPieChartComponent,
    CeoMfCategoryPieComponent,
    CeoCategoryPieChartComponent,
    CeoProductPieChartComponent,
    // CeoSectorPieChartComponent,
    InvestorlistComponent,
    CeoStocksComponent,
    CeoChangepasswordComponent,
    CeoMfCategoryPieComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    ChartsModule,
    appRoutingModule
  ],
  exports: [
    AdvisorListComponent,
    AdvisorsInvestorsComponent,
    CeoMainScreenComponent,
    CeoMutualFundComponent,
    CeoNavigationBarComponent,
    CeoProfileComponent,
    UpdateprofileComponent,
    CeoAssetPieChartComponent,
    CeoCategoryPieChartComponent,
    CeoMfCategoryPieComponent,
    CeoProductPieChartComponent,
    // CeoSectorPieChartComponent,
    InvestorlistComponent,
    CeoStocksComponent,
    CeoChangepasswordComponent
  ]
})
export class CeoModule { }
