import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
// import { Console } from 'console';
import { CeoService } from '../../Services/ceo.service';


@Component({
  selector: 'app-investorlist',
  templateUrl: './investorlist.component.html',
  styleUrls: ['./investorlist.component.css']
})
export class InvestorlistComponent implements OnInit {
  constructor(private svc:CeoService){}
  investors:any=[];
  ngOnInit(): void{
    this.getAllInvestors();
  }
  getAllInvestors():any{
    this.svc.getInvestorsList().subscribe(
      (data)=>{
        this.investors = data;
        console.log(this.investors)
      },
    (err:HttpErrorResponse)=>{
      console.log(err)
    }
    )
  }

}
