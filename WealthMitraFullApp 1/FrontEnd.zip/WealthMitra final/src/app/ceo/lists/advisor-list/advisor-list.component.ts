import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CeoService } from '../../Services/ceo.service';

@Component({
  selector: 'app-advisor-list',
  templateUrl: './advisor-list.component.html',
  styleUrls: ['./advisor-list.component.css']
})
export class AdvisorListComponent implements OnInit {

  constructor(private svc:CeoService,private router:Router){}
  advisors:any;
  ngOnInit(): void {
    this.getAllAdvisors();
  }
  getAllAdvisors():any{
    this.svc.getAdvisorsList().subscribe(
      (data)=>{
        this.advisors = data;
      },
      (err:HttpErrorResponse)=>{
        console.log("Error Message one:\n" + err)
      }
    );
  }
  onClick(id:any):void{
    console.log(id);
    sessionStorage.setItem('AdvisorId',id)
    this.router.navigateByUrl('ceo-advisors-investors')
  }

}
