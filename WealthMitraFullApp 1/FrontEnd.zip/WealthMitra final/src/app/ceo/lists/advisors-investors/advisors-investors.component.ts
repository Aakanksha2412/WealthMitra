import { Component, OnInit } from '@angular/core';
import { CeoService } from '../../Services/ceo.service';


@Component({
  selector: 'app-advisors-investors',
  templateUrl: './advisors-investors.component.html',
  styleUrls: ['./advisors-investors.component.css']
})
export class AdvisorsInvestorsComponent implements OnInit {
  constructor(private svc:CeoService){}
  investors:any;
  advisorId:any;
  ngOnInit(): void {
    this.getAdvisorInvestor();
  }
  getAdvisorInvestor():void{
    this.advisorId = sessionStorage.getItem('AdvisorId');
    console.log(this.advisorId);
    this.svc.getAdvisorInvestors(this.advisorId).subscribe(
      (data)=>{
        this.investors = data;
      },
      (err)=>{
        console.log(err);
      }
    )
  }
}
