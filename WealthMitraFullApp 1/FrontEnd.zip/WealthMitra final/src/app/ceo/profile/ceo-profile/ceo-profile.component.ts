import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { CeoService } from '../../Services/ceo.service';

@Component({
  selector: 'app-ceo-profile',
  templateUrl: './ceo-profile.component.html',
  styleUrls: ['./ceo-profile.component.css']
})
export class CeoProfileComponent implements OnInit {

  username:any;
  ceo:any;
  ceoId:any;
  status:any=false;

  constructor(private svc:CeoService) { }

  ngOnInit(): void {
    this.getInvestorProfile();
  }
  getInvestorProfile():void{
    
    this.username = sessionStorage.getItem('userName');
    this.svc.getCEOProfileDetails(this.username).subscribe(
    (data)=>{
      this.ceo = data;
      this.ceoId= data.EmployeeId;

      sessionStorage.setItem('CeoId',this.ceoId);

      this.status = true;
      
            
    },
    (err:HttpErrorResponse)=>{
      console.log("Error Message one:\n" + err)
    }
    
    )
  }

}
