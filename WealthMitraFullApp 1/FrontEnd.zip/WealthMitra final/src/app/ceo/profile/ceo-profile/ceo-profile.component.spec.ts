import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CeoProfileComponent } from './ceo-profile.component';

describe('CeoProfileComponent', () => {
  let component: CeoProfileComponent;
  let fixture: ComponentFixture<CeoProfileComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CeoProfileComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CeoProfileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
