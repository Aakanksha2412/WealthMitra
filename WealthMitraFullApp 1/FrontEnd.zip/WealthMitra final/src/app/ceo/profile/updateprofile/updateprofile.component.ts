import { Component, OnInit } from '@angular/core';
import{HttpClient, HttpErrorResponse} from '@angular/common/http';
import { FormGroup, FormBuilder,Validator } from '@angular/forms';
import {Router} from '@angular/router';
import { CeoService } from '../../Services/ceo.service';

@Component({
  selector: 'app-updateprofile',
  templateUrl: './updateprofile.component.html',
  styleUrls: ['./updateprofile.component.css']
})
export class UpdateprofileComponent implements OnInit {
  ceo:any;
  username:any;
  ceoProfile:any;
  obj:any;

  public updateForm!:FormGroup;
  constructor(private svc:CeoService, private formBuilder : FormBuilder, private http : HttpClient, private router:Router) {  }

  ngOnInit(): void {

    this.ceo=this.getCEOProfile()
  }
  getCEOProfile():void{
    
    this.username = sessionStorage.getItem('userName');
    this.svc.getCEOProfileDetails(this.username).subscribe(
    (data)=>{
      this.ceo = data;
      
    },
    (err:HttpErrorResponse)=>{
      console.log("Error Message one:\n" + err)
    }
    
    )
  }

  update(form:any):void{
    var id = sessionStorage.getItem("CeoId");
    this.obj={
      "FName": form.FName,
      "MName": form.middleName,
      "LName": form.lastName,
      "Email": form.email,
      "MobileNo": form.mobileNo,
      "AltrnateMobileNo": form.alternateMobileNo,
      "Age": form.age,
      "Pan": form.pan,
      "Gender": form.gender,
      "DOB": form.DOB,
      "MaritalStatus": form.MaritalStatus,
      "AddressLine1": form.address1,
      "AddressLine2": form.address2,
      "Pincode": form.pincode,
      "AadharNo": form.aadharNo,
      "CityName": form.cityName,
      "Experience":form.experience,
      "JoiningDate":form.JoiningDate
    }

    console.log(this.obj);
    this.http.put("http://localhost:4000/employees/updateemployee/"+id,this.obj)
  .subscribe(res=>{
    alert("Updated Profile Successful");
  
    this.router.navigate(['ceo-profile'])
  },err=>{
    alert("something went wrong, please fill all the fields.");
  })
}
}
