import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CeoChangepasswordComponent } from './ceo-changepassword.component';

describe('CeoChangepasswordComponent', () => {
  let component: CeoChangepasswordComponent;
  let fixture: ComponentFixture<CeoChangepasswordComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CeoChangepasswordComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CeoChangepasswordComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
