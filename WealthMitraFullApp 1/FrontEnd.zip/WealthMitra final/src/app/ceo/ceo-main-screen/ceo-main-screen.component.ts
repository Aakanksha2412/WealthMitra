import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { CeoService } from '../Services/ceo.service';

@Component({
  selector: 'app-ceo-main-screen',
  templateUrl: './ceo-main-screen.component.html',
  styleUrls: ['./ceo-main-screen.component.css']
})
export class CeoMainScreenComponent implements OnInit {

  constructor(private svc:CeoService) {
    
  }
  username:any;
  ceoId:any;

  profitLoss:any;
  roi:any;
  totalInvestment:any;

  
  values:any;
  message:any;
  ngOnInit(): void {
    this.getCEOCalculationsForDashboard();
  }

  getCEOCalculationsForDashboard():any{
  
        //Feeding InvestorId to getAssetInvestmentDetails
        this.svc.getCalculationsofCEO().subscribe( 
          (usrs)=>{
            this.values=usrs;
            console.log(this.values)
            for(var k of this.values)
            {
              this.profitLoss=k.ProfitLoss;
              this.roi=k.ROI;
              this.totalInvestment=k.TotalValueOfInvestment
            }
          },
          
          (err:HttpErrorResponse)=>{
            this.message=err;
            console.log("Error Message twqo:\n"+err);
          });
  
  }

}
