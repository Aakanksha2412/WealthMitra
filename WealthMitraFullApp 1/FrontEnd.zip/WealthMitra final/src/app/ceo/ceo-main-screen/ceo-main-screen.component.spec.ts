import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CeoMainScreenComponent } from './ceo-main-screen.component';

describe('CeoMainScreenComponent', () => {
  let component: CeoMainScreenComponent;
  let fixture: ComponentFixture<CeoMainScreenComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CeoMainScreenComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CeoMainScreenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
