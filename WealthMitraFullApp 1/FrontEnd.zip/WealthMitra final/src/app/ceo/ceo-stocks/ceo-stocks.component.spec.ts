import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CeoStocksComponent } from './ceo-stocks.component';

describe('CeoStocksComponent', () => {
  let component: CeoStocksComponent;
  let fixture: ComponentFixture<CeoStocksComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CeoStocksComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CeoStocksComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
