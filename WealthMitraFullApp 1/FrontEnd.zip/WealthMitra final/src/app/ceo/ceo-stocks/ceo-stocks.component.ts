import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { CeoService } from '../Services/ceo.service';

@Component({
  selector: 'app-ceo-stocks',
  templateUrl: './ceo-stocks.component.html',
  styleUrls: ['./ceo-stocks.component.css']
})
export class CeoStocksComponent implements OnInit {

  stocks:any=[]
  
  constructor(private svc:CeoService) { }
  ngOnInit(): void {
  
  this.getStockDetails();
  
  }
  getStockDetails():void{
      this.svc.getStockDetails().subscribe(
      (usrs)=>{
        this.stocks=usrs;
        },
  
      (err:HttpErrorResponse)=>{
          console.log("Error Message :\n"+err);
      });
      }
  

}
