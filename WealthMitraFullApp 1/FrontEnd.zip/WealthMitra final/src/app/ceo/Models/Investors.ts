////Use this For API////

export class Investors
{
    constructor(public FName:string,public LName:string)
    {

    }
}