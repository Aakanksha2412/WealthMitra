////Use this For API////

export class AdvisorsInvestor
{
    constructor(public FName:string,public LName:string)
    {

    }
}