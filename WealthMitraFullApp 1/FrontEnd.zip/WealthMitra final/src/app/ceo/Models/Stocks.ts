////Use this For API////

export class Stocks
{
    constructor(public StockId:string,public StockName:string,public SchemeCode:string,public AssetProductCategoryName:string,public SectorName:string,public IsActive:string,public RecordCreatedBy:string,public RecordCreatedDate:string,public RecordModifiedreatedBy:string,public RecordModifiedDate:string)
    {

    }
}