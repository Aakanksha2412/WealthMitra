////Use this For API////

export class Mutualfunds
{
    constructor(public MutualFundId:string,public MutualFundName:string,public SchemeCode:string,public AssetProductCategoryName:string,public SectorName:string,public IsActive:string,public RecordCreatedBy:string,public RecordCreatedDate:string,public RecordModifiedBy:string,public RecordModifiedDate:string)
    {

    }
}