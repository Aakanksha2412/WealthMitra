////Use this For API////

export class Advisors
{
    constructor(public FName:string,public LName:string)
    {

    }
}