import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CeoCategoryPieChartComponent } from './ceo-category-pie-chart.component';

describe('CeoCategoryPieChartComponent', () => {
  let component: CeoCategoryPieChartComponent;
  let fixture: ComponentFixture<CeoCategoryPieChartComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CeoCategoryPieChartComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CeoCategoryPieChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
