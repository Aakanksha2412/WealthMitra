import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CeoSectorPieChartComponent } from './ceo-sector-pie-chart.component';

describe('CeoSectorPieChartComponent', () => {
  let component: CeoSectorPieChartComponent;
  let fixture: ComponentFixture<CeoSectorPieChartComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CeoSectorPieChartComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CeoSectorPieChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
