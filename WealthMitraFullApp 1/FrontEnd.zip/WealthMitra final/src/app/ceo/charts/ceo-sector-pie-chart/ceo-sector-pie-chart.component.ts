import { Component, OnInit } from '@angular/core';
import { SingleDataSet, Label } from 'ng2-charts';
import { ChartType ,ChartOptions } from 'chart.js';
@Component({
  selector: 'app-ceo-sector-pie-chart',
  templateUrl: './ceo-sector-pie-chart.component.html',
  styleUrls: ['./ceo-sector-pie-chart.component.css']
})
export class CeoSectorPieChartComponent implements OnInit {
  public pieSectorChartOptions: ChartOptions = {
    responsive: true,
  };
  public pieSectorChartLabels: Label[] = ['It', 'Elcetronics','Health' ];
  public pieSectorChartData: SingleDataSet = [5000, 50000, 10000];
  public pieSectorChartType: ChartType = 'pie';
  public pieSectorChartLegend = true;
  public pieSectorChartPlugins = [];
  constructor() { }

  ngOnInit(): void {
  }

}
