import { Component, OnInit } from '@angular/core';
import { SingleDataSet, Label, monkeyPatchChartJsLegend, monkeyPatchChartJsTooltip } from 'ng2-charts';
import { ChartType ,ChartOptions } from 'chart.js'
import { HttpErrorResponse } from '@angular/common/http';
import { CeoService } from '../../Services/ceo.service';
@Component({
  selector: 'app-ceo-product-pie-chart',
  templateUrl: './ceo-product-pie-chart.component.html',
  styleUrls: ['./ceo-product-pie-chart.component.css']
})
export class CeoProductPieChartComponent implements OnInit {
  data:any=[];
  dataKey:any=[];
  dataValue:any=[];
  public pieProductChartOptions: ChartOptions = {
    responsive: true,
  };

  public pieProductChartLabels: Label[] =this.dataKey;
  public pieProductChartData: SingleDataSet = this.dataValue;
  public pieProductChartType: ChartType = 'pie';
  public pieProductChartLegend = true;
  public pieProductChartPlugins = [];
  public pieColor: any[] = [ {
    backgroundColor: ['rgba(30, 169, 224, 0.8)',
    'rgba(255,165,0,0.9)',
    'rgba(139, 136, 136, 0.9)',
    'rgba(255, 161, 181, 0.9)',
    'rgba(255, 102, 0, 0.9)'
    ]
}]

  assets:any
  productInvestment:any;
  message:any;
  metaData:any=[];

  constructor(private svc:CeoService) { 
  }

  ngOnInit(): void {
    this.getProducInvestmentDetails();
  }

  getProducInvestmentDetails():void{
        this.svc.getProductInvestmentDetails().subscribe( 
          (usrs)=>{
            this.productInvestment=usrs;
            
            for(var k of this.productInvestment)
            {
              this.dataKey.push(k.ProductName);
              this.dataValue.push(k.TotalValue)
            }
            console.log(this.dataKey);
            console.log(this.dataValue);
          },
          
          (err:HttpErrorResponse)=>{
            this.message=err;
            console.log("Error Message:\n"+err);
          });
        
      
   
  }

}

