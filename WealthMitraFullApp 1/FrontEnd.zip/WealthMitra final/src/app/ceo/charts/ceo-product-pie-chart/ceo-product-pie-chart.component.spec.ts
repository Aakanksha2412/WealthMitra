import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CeoProductPieChartComponent } from './ceo-product-pie-chart.component';

describe('CeoProductPieChartComponent', () => {
  let component: CeoProductPieChartComponent;
  let fixture: ComponentFixture<CeoProductPieChartComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CeoProductPieChartComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CeoProductPieChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
