
import { Component, OnInit } from '@angular/core';
import { SingleDataSet, Label } from 'ng2-charts';
import { ChartType ,ChartOptions } from 'chart.js';
import { CeoService } from '../../Services/ceo.service';
import { HttpErrorResponse } from '@angular/common/http';
@Component({
  selector: 'app-ceo-mf-category-pie',
  templateUrl: './ceo-mf-category-pie.component.html',
  styleUrls: ['./ceo-mf-category-pie.component.css']
})
export class CeoMfCategoryPieComponent implements OnInit {
public pieMFCategoryChartOptions: ChartOptions = {
    responsive: true,
  };
  
  data:any=[];
  dataKey:any=[];
  dataValue:any=[];
  

  public pieMFCategoryChartLabels: Label[] =this.dataKey;
  public pieMFCategoryChartData: SingleDataSet = this.dataValue;
  public pieMFCategoryChartType: ChartType = 'pie';
  public pieMFCategoryChartLegend = true;
  public pieMFCategoryChartPlugins = [];
  public pieColor: any[] = [ {
    backgroundColor: ['rgba(30, 169, 224, 0.8)',
    'rgba(255,165,0,0.9)',
    'rgba(139, 136, 136, 0.9)',
    'rgba(255, 161, 181, 0.9)',
    'rgba(255, 102, 0, 0.9)'
    ]
}]
  constructor(private svc:CeoService) { 
  }

  // assets:any
  mfCategoryInvestment:any;
  message:any;
  metaData:any=[];

  ngOnInit(): void {
    this.getCEOMutualFundsCategory();
  }
  getCEOMutualFundsCategory():void{
        this.svc.getCeoMutualFundsCategory().subscribe( 
          (usrs)=>{
            this.mfCategoryInvestment=usrs;
            var k;
            for(k of this.mfCategoryInvestment)
            {
              // console.log(k.AssetName);
              this.dataKey.push(k.CategoryName);
              this.dataValue.push(k.TotalValue)
            }
          },
          
          (err:HttpErrorResponse)=>{
            this.message=err;
            console.log("Error Message twqo:\n"+err);
          });
        
      
    
  }


}
