import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CeoMfCategoryPieComponent } from './ceo-mf-category-pie.component';

describe('CeoMfCategoryPieComponent', () => {
  let component: CeoMfCategoryPieComponent;
  let fixture: ComponentFixture<CeoMfCategoryPieComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CeoMfCategoryPieComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CeoMfCategoryPieComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
