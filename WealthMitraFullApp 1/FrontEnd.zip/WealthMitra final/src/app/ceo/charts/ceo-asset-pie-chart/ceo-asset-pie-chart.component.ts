
import { Component, OnInit } from '@angular/core';
import { SingleDataSet, Label, monkeyPatchChartJsLegend, monkeyPatchChartJsTooltip } from 'ng2-charts';
import { ChartType ,ChartOptions } from 'chart.js'
import { HttpErrorResponse } from '@angular/common/http';
import { CeoService } from '../../Services/ceo.service';

@Component({
  selector: 'app-ceo-asset-pie-chart',
  templateUrl: './ceo-asset-pie-chart.component.html',
  styleUrls: ['./ceo-asset-pie-chart.component.css']
})
export class CeoAssetPieChartComponent implements OnInit {
  public pieAssetChartOptions: ChartOptions = {
    responsive: true,
  };
  

  ceoId:any;
  data:any=[];
  dataKey:any=[];
  dataValue:any=[];
  public pieAssetChartLabels: Label[] =this.dataKey;
  public pieAssetChartData: SingleDataSet = this.dataValue;
  public pieAssetChartType: ChartType = 'pie';
  public pieAssetChartLegend = true;
  public pieAssetChartPlugins = [];
  public pieColor: any[] = [ {
    backgroundColor: ['rgba(30, 169, 224, 0.8)',
    'rgba(255,165,0,0.9)',
    'rgba(139, 136, 136, 0.9)',
    'rgba(255, 161, 181, 0.9)',
    'rgba(255, 102, 0, 0.9)'
    ]
}]

  assets:any
  assetInvestment:any;
  message:any;
  metaData:any=[];

  constructor(private svc:CeoService) { 
  }

  ngOnInit(): void {
    this.getAssetInvestmentDetails();
  }

  getAssetInvestmentDetails():void{
        this.svc.getAssetInvestmentDetails().subscribe( 
          (usrs)=>{
            this.assetInvestment=usrs;
            
            for(var k of this.assetInvestment)
            {
              this.dataKey.push(k.AssetName);
              this.dataValue.push(k.TotalValue)
            }
            console.log(this.dataKey);
            console.log(this.dataValue);
          },
          
          (err:HttpErrorResponse)=>{
            this.message=err;
            console.log("Error Message:\n"+err);
          });
        
      
   
  }

}

