import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CeoAssetPieChartComponent } from './ceo-asset-pie-chart.component';

describe('CeoAssetPieChartComponent', () => {
  let component: CeoAssetPieChartComponent;
  let fixture: ComponentFixture<CeoAssetPieChartComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CeoAssetPieChartComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CeoAssetPieChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
