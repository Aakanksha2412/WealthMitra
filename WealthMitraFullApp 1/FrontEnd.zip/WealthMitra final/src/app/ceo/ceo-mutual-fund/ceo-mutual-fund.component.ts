import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { CeoService } from '../Services/ceo.service';

@Component({
  selector: 'app-ceo-mutual-fund',
  templateUrl: './ceo-mutual-fund.component.html',
  styleUrls: ['./ceo-mutual-fund.component.css']
})
export class CeoMutualFundComponent implements OnInit {

mutualFunds:any=[]
message:any;
constructor(private svc:CeoService) { }
ngOnInit(): void {

this.getMutualFundsDetails();

}
getMutualFundsDetails():void{
    this.svc.getMutualFundsDetails().subscribe(
    (usrs)=>{
      this.mutualFunds=usrs;
      },

    (err:HttpErrorResponse)=>{

        this.message=err;
        console.log("Error Message :\n"+err);

    });
    }

}
