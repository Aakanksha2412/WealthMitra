import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CeoMutualFundComponent } from './ceo-mutual-fund.component';

describe('CeoMutualFundComponent', () => {
  let component: CeoMutualFundComponent;
  let fixture: ComponentFixture<CeoMutualFundComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CeoMutualFundComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CeoMutualFundComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
