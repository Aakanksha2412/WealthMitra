import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-ceo-navigation-bar',
  templateUrl: './ceo-navigation-bar.component.html',
  styleUrls: ['./ceo-navigation-bar.component.css']
})
export class CeoNavigationBarComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit(): void {
  }

  onLogout():void {

    sessionStorage.clear();

    this.router.navigateByUrl('login');

  }

}
