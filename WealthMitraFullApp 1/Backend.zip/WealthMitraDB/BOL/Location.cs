using System;

namespace BOL
{
    public class  Location{
        public int ID{get;set;}
        public string mainName {get;set;}
        public string subName {get; set;}
    }
}